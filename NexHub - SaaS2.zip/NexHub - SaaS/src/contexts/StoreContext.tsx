import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthContext';

interface Store {
  id: string;
  name: string;
  description: string | null;
  logo_url: string | null;
  primary_color: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  opening_hours?: any;
  delivery_settings?: any;
  payment_settings?: any;
  status: string;
  created_at: string;
  updated_at?: string;
  user_id?: string;
}

interface StoreContextType {
  stores: Store[];
  selectedStore: Store | null;
  setSelectedStore: (store: Store | null) => void;
  loading: boolean;
  refetchStores: () => Promise<void>;
  createStore: (name: string) => Promise<void>;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [stores, setStores] = useState<Store[]>([]);
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchStores = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('stores')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
        setStores(data);
        if (!selectedStore && data.length > 0) {
            setSelectedStore(data[0]);
        }
    }
    setLoading(false);
  };

  const createStore = async (name: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { data, error } = await supabase
          .from('stores')
          .insert({ 
              name, 
              status: 'active',
              user_id: user.id
          })
          .select()
          .single();
      
      if (error) throw error;
      
      if (data) {
          setStores(prev => [data, ...prev]);
          setSelectedStore(data);
      }
  };

  useEffect(() => {
    // Always load, even if no user, for local demo mode
    fetchStores();
  }, [user]);

  return (
    <StoreContext.Provider value={{ 
      stores, 
      selectedStore, 
      setSelectedStore, 
      loading, 
      refetchStores: fetchStores,
      createStore
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
