import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { LogOut, User, Building2, Phone } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const WaiterProfile = ({ staff, store }: any) => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem('nexhub_staff_session');
        navigate('/');
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 p-6 pb-24">
            <h2 className="text-2xl font-bold mb-6">Meu Perfil</h2>
            
            <div className="flex flex-col items-center mb-8">
                <Avatar className="w-24 h-24 mb-4 ring-4 ring-white shadow-lg">
                    <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${staff.name}`} />
                    <AvatarFallback><User /></AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-bold">{staff.name}</h3>
                <p className="text-gray-500 capitalize">{staff.role}</p>
            </div>

            <div className="space-y-4">
                <Card className="p-4 flex items-center gap-4">
                    <Building2 className="w-5 h-5 text-gray-400" />
                    <div>
                        <p className="text-xs text-gray-400 uppercase">Loja</p>
                        <p className="font-medium">{store.name}</p>
                    </div>
                </Card>
                
                {staff.email && (
                    <Card className="p-4 flex items-center gap-4">
                        <User className="w-5 h-5 text-gray-400" />
                        <div>
                            <p className="text-xs text-gray-400 uppercase">Email</p>
                            <p className="font-medium">{staff.email}</p>
                        </div>
                    </Card>
                )}
            </div>

            <Button variant="destructive" className="mt-auto w-full py-6 text-lg shadow-red-200 shadow-xl" onClick={handleLogout}>
                <LogOut className="mr-2 w-5 h-5" />
                Sair do Sistema
            </Button>
        </div>
    );
};
