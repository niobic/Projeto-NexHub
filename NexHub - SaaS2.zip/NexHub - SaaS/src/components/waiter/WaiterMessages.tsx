import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, User, Store } from 'lucide-react';
import { formatDate } from '@/lib/utils';
import { toast } from 'sonner';

export const WaiterMessages = ({ storeId, staffName }: any) => {
    const [messages, setMessages] = useState<any[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const [loading, setLoading] = useState(true);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        fetchMessages();

        // Optional: Subscribe to changes if Realtime is enabled
        const channel = supabase
            .channel('public:messages')
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `store_id=eq.${storeId}` }, 
                (payload) => {
                    setMessages(prev => [...prev, payload.new]);
                    scrollToBottom();
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, [storeId]);

    const fetchMessages = async () => {
        try {
            const { data, error } = await supabase
                .from('messages')
                .select('*')
                .eq('store_id', storeId)
                .order('created_at', { ascending: true });
            
            if (data) {
                setMessages(data);
                scrollToBottom();
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const scrollToBottom = () => {
        setTimeout(() => {
            if (scrollRef.current) {
                scrollRef.current.scrollIntoView({ behavior: 'smooth' });
            }
        }, 100);
    };

    const handleSend = async () => {
        if (!newMessage.trim()) return;

        try {
            const { error } = await supabase.from('messages').insert({
                store_id: storeId,
                sender_name: staffName,
                sender_type: 'staff',
                content: newMessage.trim()
            });

            if (error) throw error;
            setNewMessage('');
            // Optimistic update handled by subscription or fetch
        } catch (error) {
            console.error(error);
            toast.error('Erro ao enviar mensagem');
        }
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 pb-20">
            <div className="bg-white p-4 shadow-sm">
                <h2 className="font-bold text-lg">Chat da Equipe</h2>
                <p className="text-xs text-gray-500">Fale com a cozinha e gerência</p>
            </div>

            <ScrollArea className="flex-1 p-4">
                <div className="space-y-4 pb-4">
                    {loading ? (
                        <p className="text-center text-xs text-muted-foreground">Carregando mensagens...</p>
                    ) : messages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-10 opacity-50">
                            <Store className="w-12 h-12 mb-2" />
                            <p>Nenhuma mensagem ainda</p>
                        </div>
                    ) : (
                        messages.map((msg) => {
                            const isMe = msg.sender_name === staffName;
                            return (
                                <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-[80%] rounded-2xl p-3 ${isMe ? 'bg-primary text-primary-foreground rounded-tr-none' : 'bg-white border rounded-tl-none'}`}>
                                        <div className="flex items-center gap-2 mb-1">
                                            <span className="text-[10px] font-bold opacity-70 uppercase tracking-wider">
                                                {msg.sender_name}
                                            </span>
                                            {msg.sender_type === 'owner' && <Store className="w-3 h-3" />}
                                        </div>
                                        <p className="text-sm leading-snug">{msg.content}</p>
                                        <p className="text-[10px] opacity-50 text-right mt-1">
                                            {formatDate(msg.created_at)}
                                        </p>
                                    </div>
                                </div>
                            );
                        })
                    )}
                    <div ref={scrollRef} />
                </div>
            </ScrollArea>

            <div className="p-3 bg-white border-t flex gap-2 fixed bottom-20 left-0 right-0 z-10 w-full px-4">
                <Input 
                    value={newMessage} 
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Responza aqui..."
                    className="flex-1"
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                />
                <Button size="icon" onClick={handleSend} disabled={!newMessage.trim()}>
                    <Send className="w-4 h-4" />
                </Button>
            </div>
        </div>
    );
};
