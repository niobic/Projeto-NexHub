import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChefHat, PackageCheck, Clock } from 'lucide-react';
import { formatDate } from '@/lib/utils'; // Make sure this only uses available exports
import { formatCurrency } from '@/lib/utils';
// If formatDate is not exported from utils, I will use inline or just time.
// I edited utils.ts recently to export formatDate, so it should be fine.

export const WaiterKitchen = ({ storeId }: any) => {
    const [orders, setOrders] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchKitchenOrders();
        // Polling every 10s
        const interval = setInterval(fetchKitchenOrders, 10000);
        return () => clearInterval(interval);
    }, [storeId]);

    const fetchKitchenOrders = async () => {
        try {
            // We want orders that are preparing or ready
            const { data } = await supabase
                .from('commands')
                .select('*')
                .eq('store_id', storeId)
                .in('status', ['preparing', 'ready'])
                .order('updated_at', { ascending: false });
            
            if (data) setOrders(data);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 p-6 pb-24">
            <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Cozinha</h2>
                <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                    {orders.length} ativos
                </Badge>
            </div>

            {loading ? (
                <p className="text-center text-gray-400">Carregando...</p>
            ) : orders.length === 0 ? (
                <div className="flex flex-col items-center justify-center flex-1 opacity-50">
                    <ChefHat className="w-16 h-16 mb-4 text-gray-300" />
                    <p className="text-gray-500">Tudo entregue!</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {orders.map(order => (
                        <Card key={order.id} className="p-4 border-l-4 border-l-orange-500 overflow-hidden relative">
                             {order.status === 'ready' && (
                                <div className="absolute right-0 top-0 bg-green-500 text-white text-[10px] px-2 py-1 font-bold">
                                    PRONTO
                                </div>
                             )}
                            <div className="flex justify-between items-start mb-2">
                                <div>
                                    <h3 className="font-bold text-lg">Mesa {order.table_number}</h3>
                                    <p className="text-sm text-gray-500">{order.customer_name}</p>
                                </div>
                                <div className="text-right">
                                    <p className="font-mono font-bold">{formatCurrency(order.total_amount)}</p>
                                    <p className="text-xs text-gray-400 flex items-center justify-end gap-1">
                                        <Clock className="w-3 h-3" />
                                        {formatDate(order.created_at)}
                                    </p>
                                </div>
                            </div>
                            
                            <div className="bg-gray-50 p-2 rounded text-sm text-gray-600 mt-2">
                                {/* Ideally we fetch items for this order to show what is cooking */}
                                <span className="italic text-xs">Verificando itens...</span>
                            </div>

                            <div className="mt-3 flex justify-end">
                                <Badge 
                                    className={order.status === 'ready' ? 'bg-green-500' : 'bg-orange-500'}
                                >
                                    {order.status === 'ready' ? 'Pronto para Servir' : 'Em Preparo'}
                                </Badge>
                            </div>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
};
