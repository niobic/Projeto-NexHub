import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
    ChefHat, 
    Bell, 
    LogOut, 
    Wallet, 
    Search, 
    Plus, 
    QrCode, 
    Package, 
    RefreshCw, 
    UtensilsCrossed, 
    Clock 
} from 'lucide-react';
import { formatCurrency, formatDate } from '@/lib/utils';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export const WaiterHome = ({ 
    staff, 
    store, 
    stats, 
    commands, 
    loading, 
    fetchData, 
    handleLogout, 
    onNavigate 
}: any) => {
    
    // Convert commands to array if needed or filter locally
    const filteredCommands = commands; 

    return (
        <div className="flex flex-col min-h-full pb-24">
             {/* Modern Header */}
             <div 
                className="bg-primary pt-8 pb-32 px-6 rounded-b-[40px] shadow-xl relative overflow-hidden transition-colors duration-500"
                style={store?.primary_color ? { backgroundColor: store.primary_color } : {}}
            >
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl pointer-events-none" />
                
                <div className="flex justify-between items-center mb-8 relative z-10">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-md border border-white/20 shadow-inner">
                            <ChefHat className="w-6 h-6 text-primary-foreground" />
                        </div>
                        <div>
                            <p className="text-primary-foreground/80 text-sm font-medium">Olá, {staff.name}</p>
                            <h1 className="text-2xl font-bold text-white tracking-tight">{store?.name || 'Painel do Garçom'}</h1>
                        </div>
                    </div>
                </div>

                {/* Revenue Card */}
                <Card className="bg-white/10 border-white/10 backdrop-blur-md text-white overflow-hidden relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent skew-x-12 animate-shimmer" />
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-primary-foreground/90 font-medium flex items-center gap-2">
                                <Wallet className="w-4 h-4" />
                                Faturamento Hoje
                            </span>
                            <Badge variant="secondary" className="bg-green-500/20 text-green-100 hover:bg-green-500/30 border-0">
                                +12%
                            </Badge>
                        </div>
                        <div className="text-4xl font-extrabold tracking-tight">
                            {formatCurrency(stats.revenue)}
                        </div>
                        <div className="mt-4 flex gap-2">
                            <div className="h-1.5 flex-1 bg-black/20 rounded-full overflow-hidden">
                                <div className="h-full bg-accent w-[70%] rounded-full shadow-[0_0_10px_rgba(229,182,95,0.5)]" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Content Container */}
            <div className="flex-1 px-6 -mt-20 relative z-20">
                {/* Search Bar - Note: State lifting would be better but keeping simple for now */}
                <div className="bg-white p-2 rounded-2xl shadow-lg mb-6 flex items-center gap-2 border border-gray-100">
                    <Search className="w-5 h-5 text-gray-400 ml-3" />
                    <Input 
                        placeholder="Buscar mesa ou cliente..." 
                        className="border-0 shadow-none focus-visible:ring-0 text-gray-700 placeholder:text-gray-400 h-10"
                        onChange={(e) => {
                            // Simple filter implementation if needed, passing up would be better
                        }}
                    />
                </div>

                {/* Quick Actions */}
                <div className="grid grid-cols-4 gap-4 mb-8">
                    <QuickAction 
                        icon={Plus} 
                        label="Novo Pedido" 
                        onClick={() => onNavigate('new-order')} 
                        active 
                        customColor={store?.primary_color}
                    />
                    <QuickAction icon={QrCode} label="QR Code" onClick={() => toast.info('Ler QR Code')} />
                    <QuickAction icon={Package} label="Estoque" onClick={() => toast.info('Consultar Estoque')} />
                    <QuickAction icon={RefreshCw} label="Atualizar" onClick={fetchData} />
                </div>

                {/* Orders Section */}
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-gray-800">Pedidos Ativos</h2>
                    <Badge variant="outline" className="border-primary/20 text-primary bg-primary/5">
                        {stats.pendingCount}
                    </Badge>
                </div>

                <div className="space-y-4">
                    {loading ? (
                        <div className="flex flex-col items-center justify-center py-12 text-muted-foreground animate-pulse">
                            <ChefHat className="w-12 h-12 mb-4 opacity-50" />
                            <p>Carregando pedidos...</p>
                        </div>
                    ) : filteredCommands.length === 0 ? (
                        <Card className="p-8 text-center border-dashed border-2 bg-transparent shadow-none">
                            <p className="text-muted-foreground">Nenhum pedido encontrado</p>
                        </Card>
                    ) : (
                        filteredCommands.map((cmd: any, index: number) => (
                            <motion.div
                                key={cmd.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <Card className="overflow-hidden border-border/50 hover:shadow-lg transition-all duration-300 group">
                                    <div className="p-5 flex items-center justify-between">
                                        <div className="flex items-center gap-4">
                                            <div className="w-14 h-14 bg-primary/5 rounded-2xl flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                                                <UtensilsCrossed className="w-7 h-7" />
                                            </div>
                                            <div>
                                                <div className="flex items-center gap-2 mb-1">
                                                    <h3 className="text-lg font-bold text-gray-900">Mesa {cmd.table_number}</h3>
                                                    {cmd.status === 'open' && <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />}
                                                </div>
                                                <p className="text-sm text-muted-foreground font-medium flex items-center gap-1">
                                                    <Clock className="w-3 h-3" />
                                                    {formatDate(cmd.created_at)}
                                                </p>
                                                <p className="text-sm text-gray-500 mt-0.5 max-w-[150px] truncate">
                                                    {cmd.customer_name || 'Cliente não identificado'}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-lg font-black text-primary mb-1">
                                                {formatCurrency(cmd.total_amount)}
                                            </div>
                                            <Badge 
                                                variant="secondary" 
                                                className={`
                                                    capitalize font-semibold
                                                    ${cmd.status === 'open' ? 'bg-blue-100 text-blue-700' : ''}
                                                    ${cmd.status === 'ready' ? 'bg-green-100 text-green-700' : ''}
                                                    ${cmd.status === 'preparing' ? 'bg-orange-100 text-orange-700' : ''}
                                                `}
                                            >
                                                {cmd.status === 'open' ? 'Aberto' : cmd.status}
                                            </Badge>
                                        </div>
                                    </div>
                                </Card>
                            </motion.div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

const QuickAction = ({ icon: Icon, label, onClick, active, customColor }: any) => {
    const activeStyle = active && customColor ? { backgroundColor: customColor, boxShadow: `0 4px 14px 0 ${customColor}40` } : {};
    
    return (
        <button onClick={onClick} className="flex flex-col items-center gap-4 group">
            <div 
                className={`
                    w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm transition-all duration-300
                    ${active && !customColor ? 'bg-primary text-white shadow-primary/25' : ''}
                    ${!active ? 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-100' : ''}
                    ${active && customColor ? 'text-white' : ''}
                `}
                style={activeStyle}
            >
                <Icon className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-gray-600 group-hover:text-primary transition-colors text-center leading-tight">
                {label}
            </span>
        </button>
    );
};
