import { motion } from 'framer-motion';
import { Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const plans = [
  {
    name: 'NexHub Pro',
    description: 'Gestão completa e integrada para escalar o seu negócio',
    price: '209,99',
    period: '/mês',
    featured: true,
    badge: 'Oferta Especial',
    features: [
      { text: 'Robô com IA para Whatsapp, Instagram', included: true },
      { text: 'Catálogo/Portfólio Digital', included: true },
      { text: 'QR Code Personalizado', included: true },
      { text: 'App de Gestão e Controle Interno', included: true },
      { text: 'Pagamento Online (Rápido e Seguro)', included: true },
      { text: 'Suporte todos os dias', included: true },
      { text: 'Cupons e Cashback', included: true },
      { text: 'Recuperador de Vendas', included: true },
      { text: 'Agendamento de Serviços/Pedidos', included: true },
      { text: 'Gestão de Equipe Avançada', included: true },
      { text: 'Integração com plataformas de anúncios', included: true },
      { text: 'Gestor de Estoque', included: true },
      { text: 'Controle Financeiro', included: true, isNew: true },
      { text: 'Registro de compras', included: true, isNew: true },
    ],
  }
];

export const Pricing = () => {
  return (
    <section id="planos" className="py-24 px-4 bg-background">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-bold uppercase tracking-widest text-sm">
            Nossos Planos
          </span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground mt-2">
            Escolha a solução ideal para você
          </h2>
        </motion.div>

        <div className="max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative bg-card rounded-[2rem] md:rounded-[2.5rem] p-6 md:p-8 lg:p-12 shadow-2xl border border-primary/20 hover:border-primary/40 transition-all duration-300 overflow-hidden group"
            >
              {/* Decorative Background Mesh */}
              <div className="absolute top-0 right-0 w-[300px] md:w-[500px] h-[300px] md:h-[500px] bg-primary/5 rounded-full blur-[60px] md:blur-[100px] -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
              <div className="absolute bottom-0 left-0 w-[200px] md:w-[300px] h-[200px] md:h-[300px] bg-primary/5 rounded-full blur-[50px] md:blur-[80px] translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

              {plan.badge && (
                <div className="absolute top-0 right-0 z-20">
                  <span className="bg-primary text-white text-[10px] md:text-xs font-bold uppercase px-4 md:px-8 py-2 md:py-3 rounded-bl-2xl md:rounded-bl-3xl shadow-lg tracking-wider inline-block">
                    {plan.badge}
                  </span>
                </div>
              )}

              <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-center relative z-10">
                
                {/* Left Column: Info & Price & CTA */}
                <div className="lg:col-span-4 flex flex-col items-center lg:items-start text-center lg:text-left space-y-6 md:space-y-8">
                   <div className="space-y-3 md:space-y-4">
                      <h3 className="text-3xl md:text-4xl font-black text-foreground tracking-tight">{plan.name}</h3>
                      <p className="text-muted-foreground text-base md:text-lg leading-relaxed">{plan.description}</p>
                   </div>
                   
                   <div className="w-full">
                        <div className="flex items-start justify-center lg:justify-start gap-1 md:gap-2">
                            <span className="text-xl md:text-2xl font-bold text-primary/80 mt-2">R$</span>
                            <span className="text-5xl md:text-7xl font-black text-primary tracking-tighter">{plan.price}</span>
                            <div className="flex flex-col justify-end pb-2">
                                <span className="text-base md:text-lg text-muted-foreground font-medium">{plan.period}</span>
                            </div>
                        </div>
                        <p className="text-xs md:text-sm text-muted-foreground mt-3 text-center lg:text-left font-medium">
                           Cobrado mensalmente. Sem fidelidade.
                        </p>
                   </div>

                   <Button 
                     className="w-full py-6 md:py-8 text-lg md:text-xl font-bold bg-primary hover:bg-primary/90 text-white shadow-xl shadow-primary/25 hover:shadow-2xl hover:shadow-primary/40 rounded-xl transition-all hover:-translate-y-1 active:scale-95"
                   >
                     Assinar Agora
                   </Button>
                </div>

                {/* Divider Line (Desktop) */}
                <div className="hidden lg:block w-px self-stretch bg-gradient-to-b from-transparent via-border to-transparent lg:col-span-1 mx-auto opacity-70"></div>

                {/* Right Column: Features Grid */}
                <div className="lg:col-span-7 w-full">
                    <div className="mb-6 flex items-center gap-3">
                        <span className="h-px bg-border flex-1"></span>
                        <span className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Tudo incluso</span>
                        <span className="h-px bg-border flex-1"></span>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-x-6 gap-y-5">
                      {plan.features.map((feature, featureIndex) => (
                        <div 
                          key={featureIndex}
                          className={`flex items-start gap-3 p-3 rounded-xl transition-all duration-300 ${
                              feature.included 
                                ? 'hover:bg-primary/5 hover:translate-x-1' 
                                : ''
                          }`}
                        >
                          <div className={`mt-0.5 p-1 rounded-full shrink-0 ${feature.included ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                              {feature.included ? (
                                <Check className="w-4 h-4 stroke-[3]" />
                              ) : (
                                <X className="w-4 h-4" />
                              )}
                          </div>
                          
                          <div className="flex-1 flex items-center justify-between gap-2">
                              <span className={`text-sm font-medium leading-tight ${
                                feature.included ? 'text-foreground/90' : 'text-muted-foreground line-through opacity-60'
                              }`}>
                                {feature.text}
                              </span>
                              
                              {feature.isNew && (
                                <span className="bg-gradient-to-r from-primary to-primary-light text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-md shadow-sm">
                                  Novo
                                </span>
                              )}
                          </div>
                        </div>
                      ))}
                    </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
