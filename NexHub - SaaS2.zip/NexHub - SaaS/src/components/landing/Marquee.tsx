import { Percent, ShoppingCart } from 'lucide-react';

export const Marquee = () => {
  const items = [
    { icon: Percent, text: 'Plano Start com oferta especial' },
    { icon: ShoppingCart, text: 'Tem oferta te esperando – vem ver!' },
  ];

  // Duplicate items for seamless loop
  const duplicatedItems = [...items, ...items, ...items, ...items, ...items];

  return (
    <div className="w-full overflow-hidden bg-primary-dark py-4 relative border-y border-white/10">
      {/* Fade edges */}
      <div className="absolute left-0 top-0 w-32 h-full bg-gradient-to-r from-primary-dark to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 w-32 h-full bg-gradient-to-l from-primary-dark to-transparent z-10 pointer-events-none" />
      
      <div className="flex animate-marquee hover:pause whitespace-nowrap">
        {duplicatedItems.map((item, index) => (
          <span 
            key={index}
            className="inline-flex items-center gap-3 mx-10 text-accent font-bold uppercase tracking-wide text-sm"
          >
            <item.icon className="w-5 h-5" />
            {item.text}
          </span>
        ))}
      </div>
    </div>
  );
};
