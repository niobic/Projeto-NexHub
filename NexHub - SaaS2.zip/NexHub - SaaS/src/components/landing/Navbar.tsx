import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? 'py-3 glass shadow-lg' 
          : 'py-5 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className={`text-2xl font-extrabold tracking-tight ${scrolled ? 'text-primary' : 'text-accent'}`}>
              Nex<span className="text-accent">Hub</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a 
              href="#planos" 
              className={`font-medium transition-colors hover:text-accent ${scrolled ? 'text-foreground' : 'text-accent'}`}
            >
              Planos
            </a>
            <a 
              href="#servicos" 
              className={`font-medium transition-colors hover:text-accent ${scrolled ? 'text-foreground' : 'text-accent'}`}
            >
              Serviços
            </a>
            <a 
              href="#contato" 
              className={`font-medium transition-colors hover:text-accent ${scrolled ? 'text-foreground' : 'text-accent'}`}
            >
              Contato
            </a>
            <Link to="/auth">
              <Button 
                variant="default"
                className="bg-accent text-primary-dark hover:bg-accent/90 font-semibold px-6"
              >
                Acessar Painel
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className={`md:hidden p-2 rounded-lg ${scrolled ? 'text-foreground' : 'text-accent'}`}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-card border-t border-border"
          >
            <div className="container mx-auto px-6 py-4 flex flex-col gap-4">
              <a href="#planos" className="font-medium text-foreground py-2" onClick={() => setMobileOpen(false)}>
                Planos
              </a>
              <a href="#servicos" className="font-medium text-foreground py-2" onClick={() => setMobileOpen(false)}>
                Serviços
              </a>
              <a href="#contato" className="font-medium text-foreground py-2" onClick={() => setMobileOpen(false)}>
                Contato
              </a>
              <Link to="/auth" onClick={() => setMobileOpen(false)}>
                <Button className="w-full bg-primary text-primary-foreground">
                  Acessar Painel
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};
