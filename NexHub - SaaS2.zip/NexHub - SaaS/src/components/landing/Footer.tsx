export const Footer = () => {
  return (
    <footer className="bg-primary-dark text-white py-12 px-4">
      <div className="container mx-auto text-center">
        <div className="mb-6">
          <span className="text-2xl font-extrabold">
            Nex<span className="text-accent">Hub</span>
          </span>
          <p className="text-white/70 mt-2">Excelência em desenvolvimento digital.</p>
        </div>
        <p className="text-white/50 text-sm">
          © 2026 NexHub. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
};
