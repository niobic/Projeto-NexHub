import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export const CTA = () => {
  const handleContact = () => {
    const phone = "86999083355";
    window.open(`https://wa.me/${phone}?text=Olá NexHub, gostaria de um orçamento!`);
  };

  return (
    <>
      {/* Flyer Section */}
      <section className="py-20 px-4">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="container mx-auto max-w-6xl relative overflow-hidden rounded-[2.5rem] shadow-2xl group"
        >
          {/* Animated Gradient Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary-dark via-primary to-primary-light opacity-100 z-0 transition-all duration-500 group-hover:scale-105"></div>
          
          {/* Noise Texture */}
          <div className="absolute inset-0 opacity-20 mix-blend-overlay z-0" 
               style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='1'/%3E%3C/svg%3E")` }}>
          </div>

          {/* Glowing Orbs */}
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2 pointer-events-none z-0"></div>
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-black/40 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2 pointer-events-none z-0"></div>
          
          {/* Content */}
          <div className="relative z-10 p-12 md:p-24 text-center flex flex-col items-center justify-center space-y-8">
             <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/10 backdrop-blur-sm mb-4">
                <span className="w-2 h-2 rounded-full bg-accent animate-pulse"></span>
                <span className="text-accent text-xs font-bold tracking-widest uppercase">Premium Experience</span>
             </div>

             <h2 className="text-4xl md:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight max-w-4xl mx-auto drop-shadow-2xl">
               Transforme a experiência dos <br className="hidden md:block" />
               <span className="relative inline-block">
                 <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent via-white to-accent relative z-10">seus clientes</span>
                 <span className="absolute -bottom-2 left-0 w-full h-3 bg-accent/20 -skew-x-12 z-0 blur-sm"></span>
               </span> 
               <br className="md:hidden" /> com a NexHub
             </h2>
             
             <p className="text-white/80 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed font-medium mt-4">
               Tecnologia de ponta e design estratégico unidos para escalar seus resultados.
             </p>

             <motion.div 
               className="flex items-center justify-center gap-4 mt-8"
               initial={{ opacity: 0 }}
               whileInView={{ opacity: 1 }}
               transition={{ delay: 0.5 }}
             >
                <div className="h-[1px] w-12 md:w-24 bg-gradient-to-r from-transparent to-accent/50"></div>
                <div className="w-2 h-2 rotate-45 border border-accent bg-accent/20"></div>
                <div className="h-[1px] w-12 md:w-24 bg-gradient-to-l from-transparent to-accent/50"></div>
             </motion.div>
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section id="contato" className="py-24 px-4 bg-muted/30">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="container mx-auto text-center"
        >
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground mb-4">
            Pronto para o próximo nível?
          </h2>
          <p className="text-muted-foreground text-lg mb-8">
            Não apenas um site, mas uma máquina de vendas e automação.
          </p>
          <Button 
            onClick={handleContact}
            size="lg"
            className="bg-primary hover:bg-primary-light text-white font-semibold px-8 py-6 text-lg"
          >
            Falar com um Especialista
          </Button>
        </motion.div>
      </section>
    </>
  );
};
