import { motion } from 'framer-motion';
import { 
  MessageCircle, 
  Smartphone, 
  RefreshCcw, 
  CreditCard, 
  ClipboardList, 
  Monitor, 
  QrCode, 
  Receipt, 
  Store, 
  Package, 
  BarChart3,
  LayoutDashboard,
  Settings,
  TrendingUp,
  Users,
  ShoppingBag
} from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const featureGroups = [
  {
    id: "vendas",
    title: "Para vendas no restaurante",
    features: [
      {
        icon: MessageCircle,
        title: "Atendimento automatizado",
        description: "Atenda seus clientes automaticamente nos aplicativos que eles mais usam e potencialize as suas vendas em diversos canais."
      },
      {
        icon: Smartphone,
        title: "Cardápio Digital",
        description: "Dê autonomia aos seus clientes para pedirem seus pratos favoritos com facilidade e rapidez, diretamente de casa!"
      },
      {
        icon: RefreshCcw,
        title: "Recuperador de vendas",
        description: "Recupere clientes com mensagens automáticas e incentive o retorno ao cardápio."
      },
      {
        icon: CreditCard,
        title: "Pagamento Online",
        description: "Receba por PIX ou Crédito direto no cardápio. Simples, seguro e eficiente."
      }
    ]
  },
  {
    id: "salao",
    title: "Para atendimento no salão",
    features: [
      {
        icon: ClipboardList,
        title: "Aplicativo para Garçom",
        description: "Visualize mesas ocupadas e disponíveis, adicione itens à comanda, edite pedidos, troque clientes de mesa e feche a conta."
      },
      {
        icon: Monitor,
        title: "PDV Integrado",
        description: "Centralize seus pedidos locais e por telefone em uma única ferramenta, facilitando a rotina de trabalho"
      },
      {
        icon: QrCode,
        title: "QR Code para Mesa",
        description: "Crie um cardápio digital com QR Code para mesas e facilite o autoatendimento no seu restaurante."
      },
      {
        icon: ClipboardList,
        title: "Gestão Avançada de Comandas",
        description: "Controle total sobre o consumo das mesas. Abra, feche e transfira itens entre comandas com apenas um toque, eliminando erros de cobrança."
      }
    ]
  },
  {
    id: "gestao",
    title: "Para gestão do estabelecimento",
    features: [
      {
        icon: Receipt,
        title: "Emissão de notas fiscais",
        description: "Solução prática e intuitiva de emissão de nota fiscal, configure desde o tipo da NFC-e até a reemissão de notas canceladas."
      },
      {
        icon: Store,
        title: "Frente de Caixa",
        description: "Processo de abertura e fechamento de caixa de forma simples e prática."
      },
      {
        icon: Package,
        title: "Controle de Estoque",
        description: "Uma gestão simples no cardápio de ativação e quantidade de itens, além de uma tela de configuração das regras de operação de estoque esgotado."
      },
      {
        icon: BarChart3,
        title: "Gestor de Pedidos e Relatório",
        description: "Tenha todos os pedidos feitos em canais diferentes em um só lugar"
      }
    ]
  }
];

export const Features = () => {
  return (
    <section className="py-24 px-4 bg-background overflow-hidden">
      <div className="container mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-black text-foreground max-w-4xl mx-auto leading-tight">
            Gestão completa para <span className="text-primary">seu restaurante</span> em uma única assinatura.
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Side - Phone Image/Mockup */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="bg-transparent p-0 md:p-12 aspect-[4/3] lg:aspect-square relative flex items-center justify-center">
               {/* Background Elements */}
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-white/50 rounded-full blur-3xl -z-10"></div>
               
               {/* Phone Mockup CSS Only - No External Images */}
               <div className="relative z-10 w-[280px] sm:w-[320px] mx-auto rotate-[-6deg] hover:rotate-0 transition-all duration-700 ease-out group-hover:scale-105 select-none cursor-default">
                  {/* Phone Bezel */}
                  <div className="relative border-gray-900 bg-gray-900 border-[12px] rounded-[3rem] h-[600px] shadow-2xl overflow-hidden ring-1 ring-white/20">
                     {/* Dynamic Island / Notch */}
                     <div className="absolute top-0 left-1/2 transform -translate-x-1/2 h-7 w-28 bg-black rounded-b-2xl z-30 flex justify-center items-center">
                       <div className="w-12 h-12 bg-black/50 rounded-full blur-xl absolute top-1"></div>
                     </div>

                     {/* Screen Content - Dashboard Preview */}
                     <div className="w-full h-full bg-gray-50 flex flex-col font-sans">
                        
                        {/* App Header */}
                        <div className="bg-white pt-12 pb-4 px-6 shadow-sm z-20 flex flex-col gap-4">
                           <div className="flex justify-between items-center">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20">
                                  <Store className="w-5 h-5 text-primary" />
                                </div>
                                <div>
                                  <p className="text-gray-400 text-xs font-medium">Bom dia,</p>
                                  <p className="text-gray-800 font-bold text-lg leading-tight">NexHub Burger</p>
                                </div>
                              </div>
                              <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                              </div>
                           </div>
                           
                           {/* Date Filter */}
                           <div className="flex gap-2">
                               <span className="bg-primary text-white text-xs px-3 py-1.5 rounded-full font-medium">Hoje</span>
                               <span className="bg-gray-100 text-gray-400 text-xs px-3 py-1.5 rounded-full font-medium">7 Dias</span>
                               <span className="bg-gray-100 text-gray-400 text-xs px-3 py-1.5 rounded-full font-medium">Mês</span>
                           </div>
                        </div>

                        {/* Scrollable Dashboard Content */}
                        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
                           
                           {/* Main Revenue Card */}
                           <div className="bg-primary rounded-2xl p-5 text-white shadow-lg relative overflow-hidden group">
                               <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2 group-hover:bg-white/20 transition-colors"></div>
                               <div className="relative z-10">
                                  <p className="text-white/70 text-sm mb-1">Faturamento Total</p>
                                  <div className="flex items-end gap-2 mb-2">
                                    <h3 className="text-3xl font-black">R$ 2.850</h3>
                                    <span className="text-white/80 text-sm mb-1">,00</span>
                                  </div>
                                  <div className="flex items-center gap-1 text-sm bg-white/20 w-fit px-2 py-1 rounded-lg backdrop-blur-sm">
                                      <TrendingUp className="w-3 h-3" />
                                      <span className="font-medium">+15% vs ontem</span>
                                  </div>
                               </div>
                           </div>

                           {/* Secondary Metrics */}
                           <div className="grid grid-cols-2 gap-3">
                               <div className="bg-white p-4 rounded-xl shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] border border-gray-100 hover:border-primary/20 transition-colors">
                                  <div className="w-8 h-8 bg-orange-50 rounded-lg flex items-center justify-center text-orange-600 mb-2">
                                      <ShoppingBag className="w-4 h-4" />
                                  </div>
                                  <p className="text-gray-400 text-xs font-medium">Pedidos</p>
                                  <p className="text-xl font-bold text-gray-800">24</p>
                               </div>
                               <div className="bg-white p-4 rounded-xl shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] border border-gray-100 hover:border-primary/20 transition-colors">
                                  <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 mb-2">
                                      <Users className="w-4 h-4" />
                                  </div>
                                  <p className="text-gray-400 text-xs font-medium">Clientes</p>
                                  <p className="text-xl font-bold text-gray-800">18</p>
                               </div>
                           </div>

                           {/* Chart Section */}
                           <div className="bg-white p-5 rounded-2xl shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] border border-gray-100">
                               <div className="flex justify-between items-center mb-6">
                                  <h4 className="font-bold text-gray-800 text-sm">Vendas por Hora</h4>
                                  <BarChart3 className="w-4 h-4 text-gray-300" />
                               </div>
                               <div className="h-32 flex items-end justify-between gap-2">
                                  {[40, 70, 45, 90, 60, 85, 95, 60, 75].map((h, i) => (
                                    <div key={i} className="w-full bg-gray-50 rounded-t-sm relative group cursor-pointer" style={{height: '100%'}}>
                                       <div className="absolute bottom-0 left-0 w-full bg-primary/80 group-hover:bg-primary rounded-t-sm transition-all duration-500" style={{height: `${h}%`}}></div>
                                       {/* Tooltip hint */}
                                       <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-[10px] py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
                                          R$ {h * 10}
                                       </div>
                                    </div>
                                  ))}
                               </div>
                           </div>
                        </div>

                        {/* Bottom Navigation */}
                        <div className="bg-white border-t border-gray-100 p-4 pb-8 flex justify-between px-8">
                             <div className="flex flex-col items-center gap-1 text-primary cursor-pointer">
                                <LayoutDashboard className="w-5 h-5" />
                                <span className="text-[10px] font-bold">Início</span>
                             </div>
                             <div className="flex flex-col items-center gap-1 text-gray-300 hover:text-gray-500 cursor-pointer transition-colors">
                                <ShoppingBag className="w-5 h-5" />
                                <span className="text-[10px] font-medium">Pedidos</span>
                             </div>
                             <div className="flex flex-col items-center gap-1 text-gray-300 hover:text-gray-500 cursor-pointer transition-colors">
                                <Package className="w-5 h-5" />
                                <span className="text-[10px] font-medium">Estoque</span>
                             </div>
                             <div className="flex flex-col items-center gap-1 text-gray-300 hover:text-gray-500 cursor-pointer transition-colors">
                                <Settings className="w-5 h-5" />
                                <span className="text-[10px] font-medium">Config</span>
                             </div>
                        </div>
                     </div>
                  </div>

                  {/* Reflection/Glare */}
                  <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-tr from-transparent via-white/5 to-transparent rounded-[3rem] pointer-events-none z-40"></div>
               
                  {/* Connected Floating Cards System */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] h-[120%] z-0 pointer-events-none">
                     
                     {/* Card 1: WhatsApp (Top Right) */}
                     <div className="absolute top-[20%] right-0 lg:-right-8 bg-white p-3 rounded-2xl shadow-xl animate-[bounce_3s_infinite] flex items-center gap-3 border border-gray-100 z-50">
                        <div className="bg-[#25D366]/10 p-2 rounded-lg">
                           <MessageCircle className="w-6 h-6 text-[#25D366]" />
                        </div>
                        <div className="hidden md:block">
                           <p className="text-[10px] text-gray-400 font-bold uppercase">Pedido via</p>
                           <p className="text-xs font-bold text-gray-800">WhatsApp</p>
                        </div>
                        {/* Connection Line */}
                        <div className="absolute top-1/2 -left-12 w-12 h-[2px] bg-gradient-to-r from-transparent to-gray-200 -z-10"></div>
                     </div>

                     {/* Card 2: Store / Orders (Bottom Left) */}
                     <div className="absolute bottom-[20%] left-0 lg:-left-8 bg-white p-3 rounded-2xl shadow-xl animate-[bounce_4s_infinite_1s] flex items-center gap-3 border border-gray-100 z-50">
                        <div className="bg-primary/10 p-2 rounded-lg">
                           <Store className="w-6 h-6 text-primary" />
                        </div>
                        <div className="hidden md:block">
                           <p className="text-[10px] text-gray-400 font-bold uppercase">Loja Online</p>
                           <p className="text-xs font-bold text-gray-800">Aberta</p>
                        </div>
                         {/* Connection Line */}
                        <div className="absolute top-1/2 -right-12 w-12 h-[2px] bg-gradient-to-l from-transparent to-gray-200 -z-10"></div>
                     </div>

                     {/* Card 3: Bot / AI (Top Left) */}
                     <div className="absolute top-[15%] left-4 lg:-left-4 bg-white p-3 rounded-2xl shadow-xl animate-[pulse_3s_infinite] flex items-center gap-2 border border-gray-100 scale-90 z-40">
                        <div className="bg-blue-50 p-2 rounded-lg relative">
                           <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full border border-white"></div>
                           <Smartphone className="w-5 h-5 text-blue-600" />
                        </div>
                        <div className="hidden md:block">
                           <p className="text-xs font-bold text-gray-800">Bot Ativo</p>
                        </div>
                     </div>

                     {/* Card 4: Stats / Money (Bottom Right) */}
                     <div className="absolute bottom-[15%] right-4 lg:-right-4 bg-white p-3 rounded-2xl shadow-xl animate-[bounce_5s_infinite_0.5s] flex items-center gap-2 border border-gray-100 scale-90 z-40">
                        <div className="bg-green-50 p-2 rounded-lg">
                           <CreditCard className="w-5 h-5 text-green-600" />
                        </div>
                        <div className="hidden md:block">
                           <p className="text-xs font-bold text-green-600">+ R$ 150</p>
                        </div>
                     </div>

                  </div>
               </div>
            </div>
          </motion.div>

          {/* Right Side - Accordion Features */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Accordion type="single" defaultValue="vendas" collapsible className="w-full space-y-4">
              {featureGroups.map((group) => (
                <AccordionItem 
                  key={group.id} 
                  value={group.id}
                  className="border border-border rounded-xl overflow-hidden data-[state=open]:ring-2 data-[state=open]:ring-primary/20 transition-all"
                >
                  <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-muted/50 data-[state=open]:bg-muted/30">
                    <span className="text-lg font-bold text-foreground">{group.title}</span>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-6 pt-2 bg-muted/10">
                    <div className="space-y-6 mt-4">
                      {group.features.map((feature, idx) => (
                        <div key={idx} className="flex gap-4 items-start">
                           <div className="mt-1 p-2 bg-primary/10 rounded-lg shrink-0">
                             <feature.icon className="w-6 h-6 text-primary" />
                           </div>
                           <div>
                             <h4 className="text-base font-bold text-foreground mb-1">{feature.title}</h4>
                             <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                           </div>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
