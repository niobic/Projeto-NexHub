import { Button } from "@/components/ui/button";
import { ShoppingBag } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

interface CartSummaryProps {
  itemCount: number;
  total: number;
  onClick: () => void;
  primaryColor: string;
}

export const CartSummary = ({ itemCount, total, onClick, primaryColor }: CartSummaryProps) => {
  if (itemCount === 0) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-white via-white to-transparent z-40 pointer-events-none">
      <div className="max-w-4xl mx-auto pointer-events-auto">
        <Button 
          onClick={onClick}
          className="w-full h-14 rounded-xl shadow-lg flex items-center justify-between px-6 text-white hover:brightness-110 transition-all transform active:scale-95"
          style={{ backgroundColor: primaryColor }}
        >
           <div className="flex items-center gap-3">
              <div className="bg-black/20 px-3 py-1 rounded-full text-sm font-bold">
                 {itemCount}
              </div>
              <span className="font-semibold">Ver sacola</span>
           </div>
           <span className="font-bold text-lg">
              {formatCurrency(total)}
           </span>
        </Button>
      </div>
    </div>
  );
};
