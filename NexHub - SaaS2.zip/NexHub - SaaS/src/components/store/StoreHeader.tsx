import { Share2, Search, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface StoreHeaderProps {
  store: {
    name: string;
    logo_url: string | null;
    primary_color: string | null;
    phone: string | null;
  };
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const StoreHeader = ({ store, searchQuery, setSearchQuery }: StoreHeaderProps) => {
  const primaryColor = store.primary_color || "#561C24";

  return (
    <div className="w-full relative bg-gray-50 pb-2">
      {/* Cover / Brand Area */}
      <div 
        style={{ backgroundColor: primaryColor }} 
        className="w-full text-white pt-8 pb-10 px-4 shadow-sm relative overflow-hidden transition-colors duration-500"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/5 to-black/20"></div>
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row items-center md:items-start md:justify-between gap-4">
            
            {/* Store Info */}
            <div className="flex flex-col md:flex-row items-center gap-4 text-center md:text-left">
               {store.logo_url ? (
                  <img src={store.logo_url} alt={store.name} className="w-20 h-20 rounded-full border-4 border-white shadow-md bg-white object-cover" />
               ) : (
                  <div className="w-20 h-20 rounded-full border-4 border-white shadow-md bg-white/20 flex items-center justify-center text-3xl font-bold">
                      {store.name.substring(0, 1)}
                  </div>
               )}
               <div>
                 <h1 className="text-2xl md:text-3xl font-bold tracking-tight shadow-sm">{store.name}</h1>
                 
                 <div className="mt-2 flex items-center justify-center md:justify-start gap-3 text-sm font-medium">
                    <span className="bg-emerald-500/90 text-white px-3 py-0.5 rounded-full flex items-center gap-1.5 shadow-sm">
                       <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></div>
                       Aberto agora
                    </span>
                    {store.phone && (
                       <span className="flex items-center gap-1.5 opacity-90">
                          <Smartphone className="w-4 h-4" /> {store.phone}
                       </span>
                    )}
                 </div>
               </div>
            </div>

            {/* Actions */}
            <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/20 hover:text-white rounded-full h-10 w-10 absolute right-0 top-0 md:static" 
                onClick={() => {
                    if(navigator.share) {
                        navigator.share({
                            title: store.name,
                            url: window.location.href
                        })
                    }
                }}
            >
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Search Bar - Floating */}
      <div className="max-w-4xl mx-auto px-4 -mt-6 relative z-20">
         <div className="relative shadow-lg rounded-xl overflow-hidden bg-white ring-1 ring-black/5">
             <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
             <Input 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="O que você procura hoje?" 
                className="pl-12 bg-white border-none h-14 text-base placeholder:text-gray-400 focus-visible:ring-0 rounded-none"
             />
         </div>
      </div>
    </div>
  );
};
