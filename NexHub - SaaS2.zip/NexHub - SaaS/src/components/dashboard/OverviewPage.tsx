import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart, DollarSign, Users, Clock, Store, Plus, TrendingUp, TrendingDown } from 'lucide-react';
import { useStore } from '@/contexts/StoreContext';
import { supabase } from '@/integrations/supabase/client';

interface OverviewPageProps {
  onCreateStore: () => void;
}

export const OverviewPage = ({ onCreateStore }: OverviewPageProps) => {
  const { stores, selectedStore } = useStore();
  const [stats, setStats] = useState({
    ordersToday: 0,
    revenueToday: 0,
    newCustomers: 0,
    pendingOrders: 0,
  });
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (selectedStore) {
      fetchStats();
      fetchRecentOrders();
    } else {
      setLoading(false);
    }
  }, [selectedStore]);

  const fetchStats = async () => {
    if (!selectedStore) return;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Fetch orders today
    const { data: ordersData } = await supabase
      .from('orders')
      .select('*')
      .eq('store_id', selectedStore.id)
      .gte('created_at', today.toISOString());

    // Fetch new customers today (Assuming customers table or derive from orders)
    // For now, let's use orders to count unique customers today if customers table is not populated
    const { data: customersData } = await supabase
      .from('customers')
      .select('*')
      .eq('store_id', selectedStore.id)
      .gte('created_at', today.toISOString());

    // Fetch pending orders
    const { data: pendingData } = await supabase
      .from('orders')
      .select('*')
      .eq('store_id', selectedStore.id)
      .eq('status', 'pending');

    const orders = ordersData || [];
    const revenue = orders.reduce((sum, order) => sum + Number(order.total), 0);

    setStats({
      ordersToday: orders.length,
      revenueToday: revenue,
      newCustomers: customersData?.length || 0,
      pendingOrders: pendingData?.length || 0,
    });
  };

  const fetchRecentOrders = async () => {
    if (!selectedStore) return;

    const { data } = await supabase
      .from('orders')
      .select('*')
      .eq('store_id', selectedStore.id)
      .order('created_at', { ascending: false })
      .limit(5);

    setRecentOrders(data || []);
    setLoading(false);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (date: string) => {
    const d = new Date(date);
    const now = new Date();
    const isToday = d.toDateString() === now.toDateString();
    
    if (isToday) {
      return `Hoje, ${d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
    }
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-warning/20 text-warning-foreground',
      completed: 'bg-success/20 text-success',
      cancelled: 'bg-destructive/20 text-destructive',
    };
    const labels: Record<string, string> = {
      pending: 'Pendente',
      completed: 'Concluído',
      cancelled: 'Cancelado',
    };
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${styles[status] || 'bg-muted text-muted-foreground'}`}>
        {labels[status] || status}
      </span>
    );
  };

  if (stores.length === 0) {
    return (
      <Card className="p-12 text-center">
        <Store className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
        <h2 className="text-xl font-bold mb-2">Nenhuma loja cadastrada</h2>
        <p className="text-muted-foreground mb-6">Crie sua primeira loja para começar a gerenciar seu negócio.</p>
        <Button onClick={onCreateStore} className="bg-primary hover:bg-primary-light text-white">
          <Plus className="w-4 h-4 mr-2" /> Criar Loja
        </Button>
      </Card>
    );
  }

  if (!selectedStore) {
    return <div className="p-8 text-center text-muted-foreground">Selecione uma loja para ver o resumo.</div>;
  }

  const statCards = [
    { icon: ShoppingCart, label: 'Vendas Hoje', value: stats.ordersToday.toString(), color: 'bg-primary/10 text-primary' },
    { icon: DollarSign, label: 'Faturamento Hoje', value: formatCurrency(stats.revenueToday), color: 'bg-green-100 text-green-600' },
    { icon: Users, label: 'Novos Clientes', value: stats.newCustomers.toString(), color: 'bg-orange-100 text-orange-600' },
    { icon: Clock, label: 'Pedidos Pendentes', value: stats.pendingOrders.toString(), color: 'bg-purple-100 text-purple-600' },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <Card key={stat.label} className="p-4 md:p-6 flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${stat.color}`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xl md:text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-xs md:text-sm text-muted-foreground">{stat.label}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="flex justify-end">
          <Button
            variant="outline"
            className="gap-2"
            asChild
          >
            <a
              href={selectedStore?.slug ? `/loja/${selectedStore.slug}` : `/loja/${selectedStore?.id}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Store className="w-4 h-4" />
              Acessar Loja Online
            </a>
          </Button>
      </div>

      {/* Recent Orders */}
      <Card className="overflow-hidden">
        <div className="p-6 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold text-lg">Pedidos Recentes</h3>
        </div>
        {recentOrders.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="text-muted-foreground">Nenhum pedido recente encontrado</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 border-b">
                <tr>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">ID</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Cliente</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Valor</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Status</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Data</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-muted/50 transition-colors">
                    <td className="py-3 px-4 font-mono text-xs">#{order.id.slice(0, 8)}</td>
                    <td className="py-3 px-4 font-medium">{order.customer_name}</td>
                    <td className="py-3 px-4 font-semibold text-primary">{formatCurrency(order.total)}</td>
                    <td className="py-3 px-4">{getStatusBadge(order.status)}</td>
                    <td className="py-3 px-4 text-muted-foreground text-xs">{formatDate(order.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
};
