import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useStore } from '@/contexts/StoreContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Store, User, Save, Plus, Trash2, Clock, Truck, CreditCard, Download, Upload } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const SettingsPage = () => {
  const { user } = useAuth();
  const { selectedStore, stores, refetchStores, setSelectedStore } = useStore();
  const [loading, setLoading] = useState(false);
  
  const [storeForm, setStoreForm] = useState<any>({
    name: '',
    description: '',
    phone: '',
    email: '',
    address: '',
    primary_color: '#561C24',
    logo_url: '',
    opening_hours: { monday: {open: '08:00', close: '18:00', closed: false} },
    delivery_settings: { type: 'fixed', fee: 0, free_shipping_min: 0, pickup_enabled: true },
    payment_settings: { type: 'whatsapp', pix_key: '', pix_key_type: 'cpf' }
  });

  useEffect(() => {
    if (selectedStore) {
      setStoreForm({
        name: selectedStore.name,
        description: selectedStore.description || '',
        phone: selectedStore.phone || '',
        email: selectedStore.email || '',
        address: selectedStore.address || '',
        primary_color: selectedStore.primary_color || '#561C24',
        logo_url: selectedStore.logo_url || '',
        opening_hours: selectedStore.opening_hours || { monday: {open: '08:00', close: '18:00', closed: false} },
        delivery_settings: selectedStore.delivery_settings || { type: 'fixed', fee: 0, free_shipping_min: 0, pickup_enabled: true },
        payment_settings: selectedStore.payment_settings || { type: 'whatsapp', pix_key: '', pix_key_type: 'cpf' }
      });
    }
  }, [selectedStore]);

  const handleSaveStore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStore) return;
    setLoading(true);

    const { error } = await supabase
      .from('stores')
      .update({
        name: storeForm.name,
        description: storeForm.description,
        phone: storeForm.phone,
        email: storeForm.email,
        address: storeForm.address,
        primary_color: storeForm.primary_color,
        logo_url: storeForm.logo_url,
        opening_hours: storeForm.opening_hours,
        delivery_settings: storeForm.delivery_settings,
        payment_settings: storeForm.payment_settings
      })
      .eq('id', selectedStore.id);

    if (error) {
        console.error("Erro ao salvar:", error);
        toast.error(`Erro ao salvar: ${error.message}`);
    } else {
        toast.success("Configurações salvas (Nuvem)!");
        // Update local context
        setSelectedStore({
            ...selectedStore,
            ...storeForm
        });
        refetchStores();
    }
    
    setLoading(false);
  };

  const DAYS = [
    { key: 'monday', label: 'Segunda-feira' },
    { key: 'tuesday', label: 'Terça-feira' },
    { key: 'wednesday', label: 'Quarta-feira' },
    { key: 'thursday', label: 'Quinta-feira' },
    { key: 'friday', label: 'Sexta-feira' },
    { key: 'saturday', label: 'Sábado' },
    { key: 'sunday', label: 'Domingo' },
  ];

  const updateHours = (day: string, field: string, value: any) => {
      setStoreForm((prev: any) => ({
          ...prev,
          opening_hours: {
              ...prev.opening_hours,
              [day]: {
                  ...(prev.opening_hours?.[day] || { open: '08:00', close: '18:00', closed: false }),
                  [field]: value
              }
          }
      }));
  };

  const updateDelivery = (key: string, value: any) => {
      setStoreForm(prev => ({
          ...prev, 
          delivery_settings: { ...prev.delivery_settings, [key]: value }
      }));
  };

  const updatePayment = (key: string, value: any) => {
      setStoreForm((prev: any) => ({
          ...prev, 
          payment_settings: { ...prev.payment_settings, [key]: value }
      }));
  };

  const handleExportData = () => {
      const data = {
          stores: localStorage.getItem('nexhub-stores'),
          products: localStorage.getItem('nexhub-products'),
          categories: localStorage.getItem('nexhub-categories'),
          options: localStorage.getItem('nexhub-options'),
          items: localStorage.getItem('nexhub-items'),
          orders: localStorage.getItem('nexhub-orders')
      };
      
      const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-loja-${selectedStore.name}-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("Backup baixado com sucesso!");
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
          try {
              const data = JSON.parse(event.target?.result as string);
              if (data.stores) localStorage.setItem('nexhub-stores', data.stores);
              if (data.products) localStorage.setItem('nexhub-products', data.products);
              if (data.categories) localStorage.setItem('nexhub-categories', data.categories);
              if (data.options) localStorage.setItem('nexhub-options', data.options);
              if (data.items) localStorage.setItem('nexhub-items', data.items);
              if (data.orders) localStorage.setItem('nexhub-orders', data.orders);
              
              toast.success("Dados importados com sucesso! A página será recarregada.");
              setTimeout(() => window.location.reload(), 1500);
          } catch (err) {
              console.error(err);
              toast.error("Erro ao ler arquivo de backup.");
          }
      };
      reader.readAsText(file);
  };

  useEffect(() => {
    if (!selectedStore && stores.length > 0) {
      setSelectedStore(stores[0]);
    }
  }, [selectedStore, stores, setSelectedStore]);

  if (!selectedStore) {
    return (
      <div className="flex flex-col items-center justify-center p-8 space-y-4">
        <p className="text-lg text-muted-foreground">Selecione uma loja para configurar ou crie uma nova.</p>
        {stores.length === 0 && (
           <Button>Criar Loja (Use o botão na página inicial)</Button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-10 animate-fade-in">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-muted/30 p-4 rounded-lg border">
        <div className="flex gap-4 items-center w-full sm:w-auto">
            <Button variant="outline" asChild className="w-full sm:w-auto bg-background">
                <a href={`/s/${selectedStore.id}`} target="_blank" rel="noopener noreferrer">
                    <Store className="w-4 h-4 mr-2" /> Ver Loja Online
                </a>
            </Button>
        </div>
        <Button onClick={handleSaveStore} disabled={loading} className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-white shadow-sm">
          <Save className="w-4 h-4 mr-2" />
          {loading ? 'Salvando...' : 'Salvar Alterações'}
        </Button>
      </div>

      <Tabs defaultValue="general" className="w-full space-y-4">
        <div className="overflow-x-auto pb-1">
            <TabsList className="w-full sm:w-auto inline-flex justify-start">
              <TabsTrigger value="general"><Store className="w-4 h-4 mr-2" /> Geral</TabsTrigger>
              <TabsTrigger value="hours"><Clock className="w-4 h-4 mr-2" /> Horários</TabsTrigger>
              <TabsTrigger value="delivery"><Truck className="w-4 h-4 mr-2" /> Entrega</TabsTrigger>
              <TabsTrigger value="payment"><CreditCard className="w-4 h-4 mr-2" /> Pagamento</TabsTrigger>
              <TabsTrigger value="backup"><Download className="w-4 h-4 mr-2" /> Backup</TabsTrigger>
            </TabsList>
        </div>

        <TabsContent value="general" className="space-y-4">
          <Card className="p-6 space-y-4 shadow-sm">
             <div className="grid md:grid-cols-2 gap-6">
                 <div className="space-y-2">
                     <Label>Nome da Loja</Label>
                     <Input value={storeForm.name} onChange={e => setStoreForm({...storeForm, name: e.target.value})} />
                 </div>
                 <div className="space-y-2">
                     <Label>Telefone / WhatsApp</Label>
                     <Input value={storeForm.phone} onChange={e => setStoreForm({...storeForm, phone: e.target.value})} placeholder="Ex: 11999999999" />
                 </div>
                 <div className="space-y-2">
                     <Label>Logo URL</Label>
                     <div className="flex gap-2">
                        <Input value={storeForm.logo_url} onChange={e => setStoreForm({...storeForm, logo_url: e.target.value})} placeholder="https://..." />
                        {storeForm.logo_url && <img src={storeForm.logo_url} alt="Logo" className="w-10 h-10 rounded border object-cover" />}
                     </div>
                 </div>
                 <div className="space-y-2">
                     <Label>Cor da Marca</Label>
                     <div className="flex gap-2">
                         <Input type="color" className="w-12 h-10 p-1 cursor-pointer" value={storeForm.primary_color} onChange={e => setStoreForm({...storeForm, primary_color: e.target.value})} />
                         <Input value={storeForm.primary_color} onChange={e => setStoreForm({...storeForm, primary_color: e.target.value})} />
                     </div>
                 </div>
             </div>
             <div className="space-y-2">
                 <Label>Descrição da Loja</Label>
                 <Textarea className="min-h-[100px]" value={storeForm.description} onChange={e => setStoreForm({...storeForm, description: e.target.value})} placeholder="Conte um pouco sobre sua loja..." />
             </div>
             <div className="space-y-2">
                 <Label>Endereço Completo</Label>
                 <Input value={storeForm.address} onChange={e => setStoreForm({...storeForm, address: e.target.value})} placeholder="Rua, Número, Bairro, Cidade - UF" />
             </div>
          </Card>
        </TabsContent>

        <TabsContent value="hours">
           <Card className="p-6 shadow-sm">
              <div className="space-y-4">
                  {DAYS.map((day) => {
                      const daySettings = storeForm.opening_hours?.[day.key] || { open: '08:00', close: '18:00', closed: true }; 
                      
                      return (
                          <div key={day.key} className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-4 last:border-0 last:pb-0 gap-2">
                              <div className="w-32 font-medium">{day.label}</div>
                              
                              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                                  <div className="flex items-center gap-2">
                                      <Switch 
                                          checked={!daySettings.closed}
                                          onCheckedChange={(checked) => updateHours(day.key, 'closed', !checked)}
                                      />
                                      <span className={`text-sm w-16 ${daySettings.closed ? 'text-muted-foreground' : 'text-green-600 font-medium'}`}>
                                          {daySettings.closed ? 'Fechado' : 'Aberto'}
                                      </span>
                                  </div>

                                  {!daySettings.closed && (
                                      <div className="flex items-center gap-2">
                                          <Input 
                                              type="time" 
                                              className="w-32"
                                              value={daySettings.open}
                                              onChange={(e) => updateHours(day.key, 'open', e.target.value)}
                                          />
                                          <span className="text-muted-foreground">às</span>
                                          <Input 
                                              type="time" 
                                              className="w-32"
                                              value={daySettings.close}
                                              onChange={(e) => updateHours(day.key, 'close', e.target.value)}
                                          />
                                      </div>
                                  )}
                              </div>
                          </div>
                      );
                  })}
              </div>
           </Card>
        </TabsContent>

        <TabsContent value="delivery">
           <Card className="p-6 space-y-6 shadow-sm">
               <div className="flex items-center justify-between">
                   <div className="space-y-0.5">
                       <Label className="text-base">Retirada no Local</Label>
                       <p className="text-sm text-muted-foreground">O cliente pode buscar o pedido na loja.</p>
                   </div>
                   <Switch 
                      checked={storeForm.delivery_settings?.pickup_enabled} 
                      onCheckedChange={v => updateDelivery('pickup_enabled', v)} 
                   />
               </div>
               
               <div className="flex items-center justify-between border-t pt-4">
                   <div className="space-y-0.5">
                       <Label className="text-base">Taxa de Entrega Fixa</Label>
                       <p className="text-sm text-muted-foreground">Cobrar valor único por entrega.</p>
                   </div>
                   <div className="flex items-center gap-2">
                       <span className="text-sm">R$</span>
                       <Input 
                          type="number" 
                          className="w-24" 
                          value={storeForm.delivery_settings?.fee || 0}
                          onChange={e => updateDelivery('fee', Number(e.target.value))}
                       />
                   </div>
               </div>

               <div className="flex items-center justify-between border-t pt-4">
                   <div className="space-y-0.5">
                       <Label className="text-base">Frete Grátis acima de</Label>
                       <p className="text-sm text-muted-foreground">Isenção da taxa para pedidos acima deste valor.</p>
                   </div>
                   <div className="flex items-center gap-2">
                       <span className="text-sm">R$</span>
                       <Input 
                          type="number" 
                          className="w-24" 
                          value={storeForm.delivery_settings?.free_shipping_min || 0}
                          onChange={e => updateDelivery('free_shipping_min', Number(e.target.value))}
                       />
                   </div>
               </div>
           </Card>
        </TabsContent>

        <TabsContent value="payment">
           <Card className="p-6 space-y-6 shadow-sm">
              <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Método de Pagamento Principal</Label>
                    <Select value={storeForm.payment_settings?.type} onValueChange={v => updatePayment('type', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="whatsapp">Negociar no WhatsApp (Padrão)</SelectItem>
                            <SelectItem value="pix_manual">Pix Manual (Mostrar Chave e QR Code)</SelectItem>
                        </SelectContent>
                    </Select>
                  </div>
                  
                  {storeForm.payment_settings?.type === 'pix_manual' && (
                      <div className="grid md:grid-cols-2 gap-6 pt-4 border-t animate-in fade-in-50">
                          <div className="space-y-2">
                              <Label>Tipo de Chave Pix</Label>
                              <Select value={storeForm.payment_settings?.pix_key_type} onValueChange={v => updatePayment('pix_key_type', v)}>
                                  <SelectTrigger><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                      <SelectItem value="cpf">CPF</SelectItem>
                                      <SelectItem value="cnpj">CNPJ</SelectItem>
                                      <SelectItem value="email">Email</SelectItem>
                                      <SelectItem value="phone">Celular</SelectItem>
                                      <SelectItem value="random">Chave Aleatória</SelectItem>
                                  </SelectContent>
                              </Select>
                          </div>
                          <div className="space-y-2">
                              <Label>Chave Pix</Label>
                              <Input 
                                 value={storeForm.payment_settings?.pix_key || ''} 
                                 onChange={e => updatePayment('pix_key', e.target.value)}
                                 placeholder="Cole sua chave aqui"
                              />
                          </div>
                      </div>
                  )}
              </div>
           </Card>
        </TabsContent>

        <TabsContent value="backup">
           <Card className="p-6 space-y-6 shadow-sm">
               <div>
                   <h3 className="text-lg font-medium mb-2 flex items-center gap-2"><Download className="w-5 h-5" /> Exportar Dados</h3>
                   <p className="text-sm text-muted-foreground mb-4 max-w-2xl">
                       Baixe um arquivo contendo todas as suas lojas, produtos, configurações e pedidos.
                       Isso é útil para criar cópias de segurança ou migrar para outro dispositivo.
                   </p>
                   <Button onClick={handleExportData} variant="outline">
                       Baixar Backup da Loja (.json)
                   </Button>
               </div>
               
               <div className="pt-6 border-t">
                   <h3 className="text-lg font-medium mb-2 flex items-center gap-2"><Upload className="w-5 h-5" /> Importar Dados</h3>
                   <p className="text-sm text-muted-foreground mb-4 max-w-2xl">
                       Carregue um arquivo de backup (.json) para restaurar seus dados.
                       <br />
                       <span className="text-destructive font-bold">Atenção:</span> Esta ação substituirá os dados existentes neste navegador.
                   </p>
                   <div className="flex items-center gap-2">
                       <Button variant="outline" onClick={() => document.getElementById('file-upload')?.click()}>
                           Selecionar Arquivo de Backup
                       </Button>
                       <input 
                           id="file-upload" 
                           type="file" 
                           accept=".json" 
                           className="hidden" 
                           onChange={handleImportData}
                       />
                   </div>
               </div>
           </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
