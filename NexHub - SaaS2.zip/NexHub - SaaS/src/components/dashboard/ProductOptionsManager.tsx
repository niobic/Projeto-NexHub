import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { formatCurrency } from '@/lib/utils';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

interface OptionItem {
  id: string;
  option_id?: string;
  name: string;
  price: number;
}

interface ProductOption {
  id: string;
  product_id?: string;
  name: string;
  type: 'single' | 'multiple';
  required: boolean;
  min_selection: number;
  max_selection: number | null;
  items: OptionItem[];
  created_at?: string;
}

type OptionType = 'single' | 'multiple';

interface ProductOptionsManagerProps {
  productId: string;
  productName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const ProductOptionsManager = ({ productId, productName, open, onOpenChange }: ProductOptionsManagerProps) => {
  const [options, setOptions] = useState<ProductOption[]>([]);
  const [loading, setLoading] = useState(false);

  // Form states
  const [isAddingOption, setIsAddingOption] = useState(false);
    const [newOption, setNewOption] = useState<{
        name: string;
        type: OptionType;
        required: boolean;
        min: number;
        max: number | null;
    }>({
        name: '',
        type: 'single',
        required: false,
        min: 0,
        max: 1,
    });

  const [newItemParentId, setNewItemParentId] = useState<string | null>(null);
  const [newItem, setNewItem] = useState({ name: '', price: '' });

  useEffect(() => {
    if (open && productId) {
      fetchOptions();
    }
  }, [open, productId]);

  const fetchOptions = async () => {
    setLoading(true);
    try {
        const { data: optionsData, error: optionsError } = await supabase
          .from('product_options')
          .select('*')
          .eq('product_id', productId)
          .order('created_at', { ascending: true });

        if (optionsError) throw optionsError;

        if (!optionsData || optionsData.length === 0) {
            setOptions([]);
            return;
        }

        const optionIds = optionsData.map(o => o.id);
        const { data: itemsData, error: itemsError } = await supabase
            .from('product_option_items')
            .select('*')
            .in('option_id', optionIds);
            
        if (itemsError) throw itemsError;

        const merged: ProductOption[] = optionsData.map((opt: any) => ({
            ...opt,
            items: itemsData?.filter((i: any) => i.option_id === opt.id) || []
        }));

        setOptions(merged);
    } catch (error) {
       console.error("Error fetching options:", error);
       toast.error("Erro ao carregar opções");
    } finally {
        setLoading(false);
    }
  };

  const handleAddOption = async () => {
    if (!newOption.name) return;

    try {
        const { error } = await supabase.from('product_options').insert({
            product_id: productId,
            name: newOption.name,
            type: newOption.type,
            required: newOption.required,
            min_selection: newOption.min,
            max_selection: newOption.type === 'single' ? 1 : (newOption.max || null)
        });

        if (error) throw error;
        
        toast.success("Grupo adicionado");
        setIsAddingOption(false);
        setNewOption({ name: '', type: 'single', required: false, min: 0, max: 1 });
        fetchOptions();
    } catch (error) {
        console.error(error);
        toast.error("Erro ao adicionar grupo");
    }
  };

  const handleDeleteOption = async (id: string) => {
    if(!confirm("Remover este grupo?")) return;
    
    try {
        const { error } = await supabase.from('product_options').delete().eq('id', id);
        if (error) throw error;
        toast.success("Grupo removido");
        fetchOptions();
    } catch (error) {
        console.error(error);
        toast.error("Erro ao remover grupo");
    }
  };

  const handleAddItem = async (optionId: string) => {
    if (!newItem.name) return;
    
    try {
        const { error } = await supabase.from('product_option_items').insert({
            option_id: optionId,
            name: newItem.name,
            price: parseFloat(newItem.price) || 0
        });

        if (error) throw error;
        
        setNewItem({ name: '', price: '' });
        fetchOptions(); 
        toast.success("Item adicionado");
    } catch (error) {
        console.error(error);
        toast.error("Erro ao adicionar item");
    }
  };

  const handleDeleteItem = async (itemId: string) => {
     try {
        const { error } = await supabase.from('product_option_items').delete().eq('id', itemId);
        if (error) throw error;
        fetchOptions();
        toast.success("Item removido");
     } catch (error) {
         console.error(error);
         toast.error("Erro ao remover item");
     }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Gerenciar Opções: {productName}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="flex justify-between items-center">
            <h4 className="text-sm font-medium text-muted-foreground">{options.length} grupos de opções configurados</h4>
            <Button size="sm" onClick={() => setIsAddingOption(!isAddingOption)} variant={isAddingOption ? "secondary" : "default"}>
                {isAddingOption ? "Cancelar" : "Adicionar Grupo"}
            </Button>
          </div>

          {isAddingOption && (
            <div className="border p-4 rounded-md space-y-4 bg-muted/40">
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label>Nome do Grupo (Ex: Tamanho, Molho)</Label>
                        <Input value={newOption.name} onChange={e => setNewOption({...newOption, name: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                        <Label>Tipo de Seleção</Label>
                        <Select 
                           value={newOption.type} 
                           onValueChange={(v: 'single' | 'multiple') => setNewOption({...newOption, type: v, max: v === 'single' ? 1 : 0})}
                        >
                           <SelectTrigger><SelectValue /></SelectTrigger>
                           <SelectContent>
                               <SelectItem value="single">Única (Radio)</SelectItem>
                               <SelectItem value="multiple">Múltipla (Checkbox)</SelectItem>
                           </SelectContent>
                        </Select>
                    </div>
                </div>
                
                <div className="flex items-center gap-4">
                    <div className="flex items-center space-x-2">
                        <Switch checked={newOption.required} onCheckedChange={c => setNewOption({...newOption, required: c})} />
                        <Label>Obrigatório</Label>
                    </div>

                    {newOption.type === 'multiple' && (
                        <>
                             <div className="flex items-center gap-2">
                                <Label>Mínimo:</Label>
                                <Input type="number" className="w-16 h-8" value={newOption.min} onChange={e => setNewOption({...newOption, min: parseInt(e.target.value)})} />
                             </div>
                             <div className="flex items-center gap-2">
                                <Label>Máximo:</Label>
                                <Input type="number" className="w-16 h-8" value={newOption.max || 0} onChange={e => setNewOption({...newOption, max: parseInt(e.target.value)})} />
                             </div>
                        </>
                    )}
                </div>

                <Button onClick={handleAddOption} disabled={!newOption.name}>Salvar Grupo</Button>
            </div>
          )}

          <div className="space-y-2">
             {options.map((opt) => (
                 <Accordion type="single" collapsible key={opt.id} className="border rounded-md px-4">
                     <AccordionItem value={opt.id} className="border-none">
                         <div className="flex items-center justify-between py-2">
                             <AccordionTrigger className="hover:no-underline py-2">
                                 <div className="flex flex-col items-start gap-1">
                                     <span className="font-semibold">{opt.name}</span>
                                     <span className="text-xs text-muted-foreground">
                                         {opt.type === 'single' ? 'Escolha Única' : 'Múltipla Escolha'} •
                                         {opt.required ? ' Obrigatório' : ' Opcional'}
                                     </span>
                                 </div>
                             </AccordionTrigger>
                             <Button size="icon" variant="ghost" className="text-destructive" onClick={(e) => { e.stopPropagation(); handleDeleteOption(opt.id); }}>
                                 <Trash2 className="w-4 h-4" />
                             </Button>
                         </div>
                         <AccordionContent>
                             <div className="pl-4 pb-4 space-y-3">
                                 {opt.items.map(item => (
                                     <div key={item.id} className="flex justify-between items-center text-sm border-b py-2 last:border-0 hover:bg-muted/50 px-2 rounded">
                                         <span>{item.name}</span>
                                         <div className="flex items-center gap-4">
                                             <span className="font-mono">{formatCurrency(item.price)}</span>
                                             <Button size="icon" variant="ghost" className="h-6 w-6 text-destructive" onClick={() => handleDeleteItem(item.id)}>
                                                 <Trash2 className="w-3 h-3" />
                                             </Button>
                                         </div>
                                     </div>
                                 ))}

                                 {/* Add Item Row */}
                                 <div className="flex gap-2 items-center pt-2">
                                     <Input 
                                        className="h-8 text-sm" 
                                        placeholder="Nome do item (ex: Bacon)" 
                                        value={newItemParentId === opt.id ? newItem.name : ''}
                                        onChange={e => {
                                            setNewItemParentId(opt.id);
                                            setNewItem({...newItem, name: e.target.value});
                                        }}
                                     />
                                     <Input 
                                        className="h-8 w-24 text-sm" 
                                        placeholder="R$ 0,00" 
                                        type="number" 
                                        value={newItemParentId === opt.id ? newItem.price : ''}
                                        onChange={e => {
                                            setNewItemParentId(opt.id); 
                                            setNewItem({...newItem, price: e.target.value});
                                        }}
                                     />
                                     <Button 
                                        size="sm" 
                                        disabled={newItemParentId !== opt.id || !newItem.name}
                                        onClick={() => handleAddItem(opt.id)}
                                     >
                                         <Plus className="w-4 h-4" />
                                     </Button>
                                 </div>
                             </div>
                         </AccordionContent>
                     </AccordionItem>
                 </Accordion>
             ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
