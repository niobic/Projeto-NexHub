import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useStore } from '@/contexts/StoreContext';
import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { OverviewPage } from '@/components/dashboard/OverviewPage';
import { OrdersPage } from '@/components/dashboard/OrdersPage';
import { CatalogPage } from '@/components/dashboard/CatalogPage';
import { CustomersPage } from '@/components/dashboard/CustomersPage';
import { FinancePage } from '@/components/dashboard/FinancePage';
import { SettingsPage } from '@/components/dashboard/SettingsPage';
import { CreateStoreDialog } from '@/components/dashboard/CreateStoreDialog';

const pageTitles: Record<string, string> = {
  overview: 'Visão Geral',
  orders: 'Pedidos/Serviços',
  catalog: 'Catálogo',
  customers: 'Clientes',
  finance: 'Financeiro',
  settings: 'Configurações',
};

const Dashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const { stores, loading: storeLoading } = useStore();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState('overview');
  const [showCreateStore, setShowCreateStore] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);
  
  // Force open create store dialog if user has no stores and is not loading
  useEffect(() => {
      if (!storeLoading && stores.length === 0 && !showCreateStore) {
        // Optional: uncomment to auto-open dialog
        // setShowCreateStore(true);
      }
  }, [storeLoading, stores, showCreateStore]);

  if (authLoading || storeLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const handleCreateStore = () => {
    if (stores.length > 0) {
        // Enforce 1 store limit
        return;
    }
    setShowCreateStore(true);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'overview':
        return <OverviewPage onCreateStore={handleCreateStore} />;
      case 'orders':
        return <OrdersPage />;
      case 'catalog':
        return <CatalogPage />;
      case 'customers':
        return <CustomersPage />;
      case 'finance':
        return <FinancePage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <OverviewPage onCreateStore={handleCreateStore} />;
    }
  };

  return (
    <DashboardLayout
      currentPage={currentPage}
      pageTitle={pageTitles[currentPage]}
      onPageChange={setCurrentPage}
      onCreateStore={stores.length === 0 ? handleCreateStore : undefined}
    >
      {renderPage()}
      <CreateStoreDialog 
        open={showCreateStore} 
        onOpenChange={(open) => {
            // Only allow closing if we have at least one store or if cancelling creation
            if (!open && stores.length === 0) {
                // Should we prevent closing? Maybe not, the user sees the empty state card.
            }
            setShowCreateStore(open);
        }}
        onSuccess={() => setCurrentPage('settings')}
      />
    </DashboardLayout>
  );
};

export default Dashboard;
