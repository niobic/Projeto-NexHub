import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Mail, Lock, User, ArrowLeft, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [verificationSent, setVerificationSent] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  
  const [loading, setLoading] = useState(false);
  
  const { signIn, signUp, resendConfirmationEmail, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const handleResendEmail = async () => {
    if (resendCooldown > 0) return;
    
    try {
        const { error } = await resendConfirmationEmail(email);
        if (error) {
            toast.error(error.message);
        } else {
            toast.success('Email reenviado com sucesso!');
            setResendCooldown(60); // 60 seconds cooldown
        }
    } catch (error) {
        toast.error('Erro ao reenviar email');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLogin) {
        // --- LOGIN FLOW ---
        const { error: signInError } = await signIn(email, password);
        
        if (!signInError) {
             toast.success('Login realizado!');
             // Navigation handled by useEffect
             return; 
        }

        toast.error('Email ou senha incorretos');
      } else {
        // --- SIGNUP FLOW (NO SMS) ---
        if (!fullName.trim() || !email || !password) {
             toast.error('Preencha todo os dados');
             setLoading(false);
             return;
        }

        const { error, data } = await signUp(email, password, fullName, '');

        if (error) {
             if (error.message.includes('already registered')) {
               toast.error('Este email já está cadastrado');
             } else {
               toast.error(error.message);
             }
             setLoading(false);
             return;
        }

        // Account created!
        // Check if session exists (Auto login?)
        if (data?.session) {
            toast.success('Conta criada com sucesso!');
            navigate('/dashboard');
        } else {
            // Email confirmation enabled?
            setVerificationSent(true);
            toast.success('Conta criada! Verifique seu email.');
        }
      }
    } catch (err: any) {
      toast.error(err.message || 'Erro inesperado');
    } finally {
        setLoading(false);
    }
  };

  if (verificationSent) {
    return (
      <div className="min-h-screen gradient-wine flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-card rounded-2xl shadow-2xl p-8 w-full max-w-md text-center"
        >
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <Mail className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-4">Verifique seu email</h2>
          <p className="text-muted-foreground mb-6">
            Enviamos um link de confirmação para <strong>{email}</strong>.
            <br />
            Clique no link para ativar sua conta e acessar o painel.
            <br />
            <span className="block mt-2 text-sm text-yellow-600 dark:text-yellow-500 font-medium">
              ⚠ Verifique também sua caixa de Spam ou Lixo Eletrônico.
            </span>
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-primary animate-pulse mb-4">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Aguardando confirmação...</span>
          </div>

          <div className="space-y-2">
            <Button
                variant="outline"
                className="w-full"
                onClick={handleResendEmail}
                disabled={resendCooldown > 0}
            >
                {resendCooldown > 0 ? `Reenviar em ${resendCooldown}s` : 'Reenviar Email'}
            </Button>
            
            <Button 
                variant="ghost" 
                className="w-full"
                onClick={() => setVerificationSent(false)}
            >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar para o login
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen gradient-wine flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card rounded-2xl shadow-2xl p-8 w-full max-w-md"
      >
        <Link to="/" className="block text-center mb-6">
          <span className="text-3xl font-extrabold text-primary">
            Nex<span className="text-accent">Hub</span>
          </span>
        </Link>

        <h2 className="text-2xl font-bold text-center text-foreground mb-2">
          {isLogin ? 'Acesse seu Painel' : 'Crie sua Conta'}
        </h2>
        <p className="text-muted-foreground text-center text-sm mb-6">
          {isLogin ? 'Gerencie seu negócio em um só lugar' : 'Preencha seus dados para começar'}
        </p>

        {/* Role Toggle Removed - Unified Login */}
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Seu nome completo"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="pl-10 h-11"
                required
              />
            </div>
          )}

            <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="Seu e-mail"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-11"
                  required
                />
            </div>

              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="password"
                  placeholder="Sua senha"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 h-11"
                  required
                  minLength={6}
                />
              </div>

              {!isLogin && (
                <div className="hidden">
                  {/* Phone input removed */}
                </div>
              )}

          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary-light text-white font-bold h-12 text-md mt-4"
            disabled={loading}
          >
            {loading ? (
              <Loader2 className="w-6 h-6 animate-spin mx-auto" />
            ) : (
               isLogin ? 'Entrar' : 'Continuar'
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            type="button"
            onClick={() => {
                setIsLogin(!isLogin);
            }}
            className="text-sm text-primary hover:text-accent font-semibold transition-colors"
          >
            {isLogin ? 'Não tem uma conta? Crie agora' : 'Já tem uma conta? Entrar'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default Auth;
