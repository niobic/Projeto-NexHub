
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { StoreHeader } from '@/components/store/StoreHeader';
import { CategoryNav } from '@/components/store/CategoryNav';
import { ProductCard } from '@/components/store/ProductCard';
import { Search } from 'lucide-react';
import { ProductModal } from '@/components/store/ProductModal';
import { CartSummary } from '@/components/store/CartSummary';
import { CheckoutModal } from '@/components/store/CheckoutModal';

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  category_id: string | null;
  store_id?: string;
}

interface Category {
  id: string;
  name: string;
  sort_order: number;
}

export const PublicStorePage = () => {
  const { slug } = useParams();
  const [store, setStore] = useState<any>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  
  // UI States
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  
  const [cart, setCart] = useState<any[]>([]);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  useEffect(() => {
    const fetchStoreAndProducts = async () => {
      setLoading(true);

      // 1. Fetch Store
      const { data: storeData } = await supabase
        .from('stores')
        .select('*')
        .eq('id', slug)
        .single();
        
      if (!storeData) {
          setLoading(false);
          return;
      }
      setStore(storeData);

      // 2. Fetch Categories
      const { data: categoriesData } = await supabase
        .from('categories')
        .select('*')
        .eq('store_id', storeData.id)
        .order('sort_order');
      
      setCategories(categoriesData || []);

      // 3. Fetch Products
      const { data: productsData } = await supabase
        .from('products')
        .select('*')
        .eq('store_id', storeData.id)
        .eq('status', 'active');
      
      setProducts(productsData || []);
      setLoading(false);
    };
    fetchStoreAndProducts();
  }, [slug]);



  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
    setIsProductModalOpen(true);
  };

  const handleAddToCart = (item: any) => {
    const newItem = { ...item, id: Math.random().toString(36).substr(2, 9) };
    setCart([...cart, newItem]);
    setIsProductModalOpen(false);
  };

  const handleUpdateCartQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
        if (item.id === id) {
            const newQuantity = item.quantity + delta;
            if (newQuantity < 1) return item;
            return { 
                ...item, 
                quantity: newQuantity, 
                totalPrice: (item.totalPrice / item.quantity) * newQuantity 
            };
        }
        return item;
    }));
  };

  const handleRemoveFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  // Group products by fetched categories
  const filteredProducts = products.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      (p.description && p.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Helper to get category name
  const getCategoryName = (id: string | null) => {
      if (!id) return "Outros";
      return categories.find(c => c.id === id)?.name || "Outros";
  }

  // Grouping logic: Iterate over categories to preserve sort order
  const groupedProducts: { id: string, name: string, products: Product[] }[] = [];
  
  // 1. Add categories that have products
  categories.forEach(cat => {
      const prods = filteredProducts.filter(p => p.category_id === cat.id);
      if (prods.length > 0) {
          groupedProducts.push({ id: cat.id, name: cat.name, products: prods });
      }
  });

  // 2. Add "Others" (products with no category or invalid category_id)
  const otherProds = filteredProducts.filter(p => !p.category_id || !categories.find(c => c.id === p.category_id));
  if (otherProds.length > 0) {
      groupedProducts.push({ id: 'others', name: "Outros", products: otherProds });
  }

  const handleCategorySelect = (categoryId: string) => {
    setActiveCategory(categoryId);
    const element = document.getElementById(`category-${categoryId}`);
    if (element) {
        const headerOffset = 180;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
    
        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
  </div>;

  if (!store) return <div className="min-h-screen flex items-center justify-center bg-gray-50 text-gray-500">Loja não encontrada</div>;

  const cartTotal = cart.reduce((acc, item) => acc + (item.totalPrice || 0), 0);
  const cartCount = cart.reduce((acc, item) => acc + (item.quantity || 0), 0);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col pb-24 md:pb-0 font-sans">
      <StoreHeader 
        store={store} 
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />
      
      <CategoryNav 
        categories={groupedProducts.map(g => ({ id: g.id, name: g.name }))}
        activeCategory={activeCategory}
        onSelect={handleCategorySelect}
        primaryColor={store.primary_color || '#000'}
      />

      <div className="flex-1 max-w-5xl mx-auto w-full p-4 space-y-10 mt-2">
        {groupedProducts.map((group) => (
            <section key={group.id} id={`category-${group.id}`} className="scroll-mt-40 transition-opacity duration-500">
                <div className="flex items-center gap-4 mb-6">
                    <h2 className="text-xl md:text-2xl font-bold text-gray-800 shrink-0">
                        {group.name}
                    </h2>
                    <div className="h-px bg-gray-200 flex-1"></div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                    {group.products.map(product => (
                        <ProductCard 
                            key={product.id} 
                            product={product} 
                            primaryColor={store.primary_color}
                            onSelect={() => handleProductSelect(product)}
                        />
                    ))}
                </div>
            </section>
        ))}

        {groupedProducts.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                <Search className="w-12 h-12 mb-4 opacity-20" />
                <p className="text-lg font-medium">Nenhum produto encontrado</p>
                <p className="text-sm">Tente buscar por outro termo</p>
            </div>
        )}
      </div>

      <CartSummary 
         itemCount={cartCount}
         total={cartTotal}
         primaryColor={store.primary_color}
         onClick={() => setIsCheckoutOpen(true)}
      />

      <ProductModal 
         product={selectedProduct}
         isOpen={isProductModalOpen}
         onClose={() => setIsProductModalOpen(false)}
         onAddToCart={handleAddToCart}
         primaryColor={store.primary_color}
      />

      <CheckoutModal
         isOpen={isCheckoutOpen}
         onClose={() => setIsCheckoutOpen(false)}
         cart={cart}
         store={store} // Pass full store object for payment/delivery settings
         onUpdateQuantity={handleUpdateCartQuantity}
         onRemoveItem={handleRemoveFromCart}
         onClearCart={() => setCart([])}
      />
    </div>
  );
};

export default PublicStorePage;
