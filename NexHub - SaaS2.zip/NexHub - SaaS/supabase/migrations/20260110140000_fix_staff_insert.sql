
-- Function to safely add staff members (Bypassing RLS complexity)
CREATE OR REPLACE FUNCTION public.create_staff_member(
    p_store_id UUID,
    p_name TEXT,
    p_email TEXT,
    p_password TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER -- Runs with admin privileges to bypass table RLS
AS $$
DECLARE
    v_staff_id UUID;
BEGIN
    -- 1. Security Check: Ensure the executing user owns the store
    IF NOT EXISTS (
        SELECT 1 FROM public.stores 
        WHERE id = p_store_id 
        AND user_id = auth.uid()
    ) THEN
        RAISE EXCEPTION 'Acesso negado: Você não é dono desta loja.';
    END IF;

    -- 2. Check if email already exists for this store
    IF EXISTS (
        SELECT 1 FROM public.store_staff 
        WHERE store_id = p_store_id 
        AND email = p_email
    ) THEN
        RAISE EXCEPTION 'Este email já está cadastrado nesta loja.';
    END IF;

    -- 3. Insert the new staff member
    INSERT INTO public.store_staff (store_id, name, email, password, role, active)
    VALUES (p_store_id, p_name, p_email, p_password, 'waiter', true)
    RETURNING id INTO v_staff_id;

    RETURN jsonb_build_object('id', v_staff_id, 'success', true);
END;
$$;
