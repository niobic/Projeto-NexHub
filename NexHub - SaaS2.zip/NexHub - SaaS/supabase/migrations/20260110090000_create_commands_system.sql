
-- Create commands table
CREATE TABLE IF NOT EXISTS public.commands (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  table_number TEXT NOT NULL,
  customer_name TEXT,
  waiter_name TEXT,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'paid')),
  total_amount DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create command_items table
CREATE TABLE IF NOT EXISTS public.command_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  command_id UUID NOT NULL REFERENCES public.commands(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'preparing', 'ready', 'delivered', 'cancelled')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.commands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.command_items ENABLE ROW LEVEL SECURITY;

-- Policies for commands
CREATE POLICY "Users can view their own store commands" 
ON public.commands FOR SELECT 
USING (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert commands for their stores" 
ON public.commands FOR INSERT 
WITH CHECK (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()));

CREATE POLICY "Users can update their own store commands" 
ON public.commands FOR UPDATE 
USING (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()));

CREATE POLICY "Users can delete their own store commands" 
ON public.commands FOR DELETE 
USING (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()));

-- Policies for command_items
CREATE POLICY "Users can view their own store command items" 
ON public.command_items FOR SELECT 
USING (command_id IN (SELECT id FROM public.commands WHERE store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid())));

CREATE POLICY "Users can insert command items for their stores" 
ON public.command_items FOR INSERT 
WITH CHECK (
    command_id IN (SELECT id FROM public.commands WHERE store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()))
);

CREATE POLICY "Users can update their own store command items" 
ON public.command_items FOR UPDATE 
USING (command_id IN (SELECT id FROM public.commands WHERE store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid())));

CREATE POLICY "Users can delete their own store command items" 
ON public.command_items FOR DELETE 
USING (command_id IN (SELECT id FROM public.commands WHERE store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid())));

-- RPC Function to Close Command
CREATE OR REPLACE FUNCTION public.close_command(
  p_command_id UUID,
  p_store_id UUID,
  p_payment_method TEXT DEFAULT 'cash'
) 
RETURNS VOID 
LANGUAGE plpgsql 
SECURITY DEFINER
AS $$
DECLARE
  v_total DECIMAL(10,2);
  v_item RECORD;
BEGIN
  -- 1. Calculate final total from items (ensure integrity)
  SELECT COALESCE(SUM(quantity * unit_price), 0) INTO v_total
  FROM public.command_items
  WHERE command_id = p_command_id;

  -- 2. Update Command Status
  UPDATE public.commands
  SET status = 'paid',
      total_amount = v_total,
      updated_at = now()
  WHERE id = p_command_id AND store_id = p_store_id;

  -- 3. Register Finance Transaction
  INSERT INTO public.finance_transactions (
    store_id,
    type,
    amount,
    description,
    category,
    created_at
  ) VALUES (
    p_store_id,
    'income',
    v_total,
    'Fechamento de Comanda', -- You might want to append the table number dynamically but this is okay
    'Vendas',
    now()
  );
  
  -- 4. Deduct Stock (Iterate over items)
  FOR v_item IN SELECT product_id, quantity FROM public.command_items WHERE command_id = p_command_id LOOP
      IF v_item.product_id IS NOT NULL THEN
          UPDATE public.products
          SET stock = stock - v_item.quantity
          WHERE id = v_item.product_id;
      END IF;
  END LOOP;

END;
$$;
