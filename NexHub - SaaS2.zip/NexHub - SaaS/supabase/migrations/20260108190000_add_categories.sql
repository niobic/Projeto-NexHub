-- CRIE A TABELA categories
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  image_url TEXT,
  sort_order INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- HABILITE RLS
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- REMOVE POLÍTICAS ANTIGAS SE EXISTIREM PARA EVITAR ERRO DE DUPLICIDADE
DROP POLICY IF EXISTS "Public can view categories" ON public.categories;
DROP POLICY IF EXISTS "Users can manage their own categories" ON public.categories;

CREATE POLICY "Public can view categories" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Users can manage their own categories" ON public.categories FOR ALL USING (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()));

-- CRIE COLUNAS FALTANTES
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS delivery_settings JSONB;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payment_settings JSONB;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL;
