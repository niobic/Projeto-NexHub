
-- Improve staff_login function to be case-insensitive and ignore whitespace
-- This helps prevent "Email incorrect" errors due to mobile autocorrect or typos.

CREATE OR REPLACE FUNCTION public.staff_login(
    p_email TEXT,
    p_password TEXT
)
RETURNS TABLE (
    staff_id UUID,
    store_id UUID,
    name TEXT,
    role TEXT
) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        id as staff_id,
        t.store_id,
        t.name,
        t.role
    FROM public.store_staff t
    WHERE lower(trim(t.email)) = lower(trim(p_email)) 
    AND t.password = trim(p_password) -- Passwords might have accidental trailing space too
    AND t.active = true;
END;
$$;
