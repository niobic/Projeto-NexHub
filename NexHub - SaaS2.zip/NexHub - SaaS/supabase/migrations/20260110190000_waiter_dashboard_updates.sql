-- Create messages table for staff chat
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  sender_name TEXT NOT NULL,
  sender_type TEXT NOT NULL CHECK (sender_type IN ('staff', 'owner')),
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Allow anon (staff) to insert messages if they have the store_id
CREATE POLICY "Public create messages" ON public.messages FOR INSERT WITH CHECK (true);

-- Allow anon (staff) to read messages if they belong to the store
CREATE POLICY "Public read messages" ON public.messages FOR SELECT USING (true);


-- Create RPC to create a command safely from waiter (anon) context
-- This avoids complex RLS for the user insertion
CREATE OR REPLACE FUNCTION public.create_waiter_command(
    p_store_id UUID,
    p_table_number TEXT,
    p_customer_name TEXT,
    p_waiter_name TEXT,
    p_items JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER -- Runs with elevated permissions to bypass RLS
AS $$
DECLARE
    v_command_id UUID;
    v_item JSONB;
    v_total_amount DECIMAL(10, 2) := 0;
BEGIN
    -- Calculate total
    FOR v_item IN SELECT * FROM jsonb_array_elements(p_items)
    LOOP
        v_total_amount := v_total_amount + ((v_item->>'unit_price')::DECIMAL * (v_item->>'quantity')::INTEGER);
    END LOOP;

    -- Create Command
    INSERT INTO public.commands (store_id, table_number, customer_name, waiter_name, total_amount, status)
    VALUES (p_store_id, p_table_number, p_customer_name, p_waiter_name, v_total_amount, 'open')
    RETURNING id INTO v_command_id;

    -- Create Command Items
    FOR v_item IN SELECT * FROM jsonb_array_elements(p_items)
    LOOP
        INSERT INTO public.command_items (command_id, product_id, quantity, unit_price, status)
        VALUES (
            v_command_id, 
            (v_item->>'product_id')::UUID, 
            (v_item->>'quantity')::INTEGER, 
            (v_item->>'unit_price')::DECIMAL, 
            'pending'
        );
    END LOOP;

    RETURN jsonb_build_object('command_id', v_command_id, 'status', 'success');
END;
$$;

-- Ensure public access to categories and products for menu display
DROP POLICY IF EXISTS "Public read categories" ON public.categories;
CREATE POLICY "Public read categories" ON public.categories FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public read products" ON public.products;
CREATE POLICY "Public read products" ON public.products FOR SELECT USING (true);
