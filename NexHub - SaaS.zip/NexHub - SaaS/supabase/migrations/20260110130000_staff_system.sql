
-- Create store_staff table
CREATE TABLE IF NOT EXISTS public.store_staff (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  password TEXT NOT NULL, -- In a real app, hash this! For this demo/prototype, we'll keep simple or use a basic hash function if available
  role TEXT NOT NULL DEFAULT 'waiter',
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(store_id, email)
);

-- Enable RLS
ALTER TABLE public.store_staff ENABLE ROW LEVEL SECURITY;

-- Policy: Owners can do everything on their staff
DROP POLICY IF EXISTS "Owners can manage staff" ON public.store_staff;
CREATE POLICY "Owners can manage staff" ON public.store_staff
USING (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()));

-- Function for Staff Login (bypassing Supabase Auth specific to Owners)
CREATE OR REPLACE FUNCTION public.staff_login(
    p_email TEXT,
    p_password TEXT
)
RETURNS TABLE (
    staff_id UUID,
    store_id UUID,
    name TEXT,
    role TEXT
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        id as staff_id,
        store_id,
        name,
        role
    FROM public.store_staff
    WHERE email = p_email 
    AND password = p_password
    AND active = true;
END;
$$;
