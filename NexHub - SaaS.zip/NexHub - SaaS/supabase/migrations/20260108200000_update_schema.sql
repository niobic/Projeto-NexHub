-- Create categories table
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  image_url TEXT,
  sort_order INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for categories
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Add RLS policies for categories
CREATE POLICY "Users can view their own store categories" 
ON public.categories
FOR SELECT 
USING (
  store_id IN (
    SELECT id FROM public.stores 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert categories for their stores" 
ON public.categories
FOR INSERT 
WITH CHECK (
  store_id IN (
    SELECT id FROM public.stores 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can update their own store categories" 
ON public.categories
FOR UPDATE 
USING (
  store_id IN (
    SELECT id FROM public.stores 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete their own store categories" 
ON public.categories
FOR DELETE 
USING (
  store_id IN (
    SELECT id FROM public.stores 
    WHERE user_id = auth.uid()
  )
);

-- Public read access for categories (for the public store page)
CREATE POLICY "Public can view categories" 
ON public.categories
FOR SELECT 
USING (true);


-- Add missing columns to stores table if they don't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'stores' AND column_name = 'delivery_settings') THEN
        ALTER TABLE public.stores ADD COLUMN delivery_settings JSONB;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'stores' AND column_name = 'payment_settings') THEN
        ALTER TABLE public.stores ADD COLUMN payment_settings JSONB;
    END IF;
END $$;

-- Add category_id to products if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'category_id') THEN
        ALTER TABLE public.products ADD COLUMN category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL;
    END IF;
END $$;
