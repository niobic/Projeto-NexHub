-- Allow public access to view active stores
CREATE POLICY "Public can view active stores" ON public.stores
  FOR SELECT
  USING (status = 'active');

-- Allow public access to view active products
CREATE POLICY "Public can view active products" ON public.products
  FOR SELECT
  USING (status = 'active');
