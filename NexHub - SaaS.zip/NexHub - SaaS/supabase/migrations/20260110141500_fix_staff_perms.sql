
-- Update function to include public search path and better debugging if needed
-- Also ensures we are casting IDs correctly just in case.

CREATE OR REPLACE FUNCTION public.create_staff_member(
    p_store_id UUID,
    p_name TEXT,
    p_email TEXT,
    p_password TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public -- BEST PRACTICE: Prevent search_path hijacking
AS $$
DECLARE
    v_staff_id UUID;
    v_user_id UUID;
    v_store_owner UUID;
BEGIN
    -- Get Current User ID
    v_user_id := auth.uid();
    
    -- Get Store Owner ID (Debugging/Check)
    SELECT user_id INTO v_store_owner 
    FROM public.stores 
    WHERE id = p_store_id;

    -- 1. Security Check
    IF v_store_owner IS NULL THEN
        RAISE EXCEPTION 'Loja não encontrada (ID: %)', p_store_id;
    END IF;

    IF v_store_owner != v_user_id THEN
         -- Attempt to provide helpful error if it mismatches
        RAISE EXCEPTION 'Acesso negado. Dono da loja: %, Você: %', v_store_owner, v_user_id;
    END IF;

    -- 2. Check if email already exists for this store
    IF EXISTS (
        SELECT 1 FROM public.store_staff 
        WHERE store_id = p_store_id 
        AND email = p_email
    ) THEN
        RAISE EXCEPTION 'Este email já está cadastrado nesta loja.';
    END IF;

    -- 3. Insert the new staff member
    INSERT INTO public.store_staff (store_id, name, email, password, role, active)
    VALUES (p_store_id, p_name, p_email, p_password, 'waiter', true)
    RETURNING id INTO v_staff_id;

    RETURN jsonb_build_object('id', v_staff_id, 'success', true);
END;
$$;
