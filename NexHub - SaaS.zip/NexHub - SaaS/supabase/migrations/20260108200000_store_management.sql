-- Create categories table
CREATE TABLE public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  sort_order INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for categories
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view active categories" ON public.categories
  FOR SELECT
  USING (active = true);

CREATE POLICY "Users can manage their own categories" ON public.categories
  FOR ALL
  USING (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()));

-- Add settings columns to stores
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS opening_hours JSONB DEFAULT '{"monday": {"open": "08:00", "close": "18:00", "closed": false}}',
  ADD COLUMN IF NOT EXISTS delivery_settings JSONB DEFAULT '{"type": "fixed", "fee": 0, "free_shipping_min": 0, "pickup_enabled": true}',
  ADD COLUMN IF NOT EXISTS payment_settings JSONB DEFAULT '{"type": "whatsapp", "pix_key": "", "pix_key_type": ""}';

-- Add category_id to products
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL;

-- Create product_options table for variants/addons
CREATE TABLE public.product_options (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  name TEXT NOT NULL, -- e.g. "Tamanho", "Adicionais"
  type TEXT NOT NULL CHECK (type IN ('single', 'multiple')), -- Radio or Checkbox
  required BOOLEAN DEFAULT false,
  min_selection INTEGER DEFAULT 0,
  max_selection INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create product_option_items table for the choices within an option
CREATE TABLE public.product_option_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  option_id UUID NOT NULL REFERENCES public.product_options(id) ON DELETE CASCADE,
  name TEXT NOT NULL, -- e.g. "300ml", "Bacon"
  price DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for options
ALTER TABLE public.product_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_option_items ENABLE ROW LEVEL SECURITY;

-- Public policies for options
CREATE POLICY "Public can view product options" ON public.product_options FOR SELECT USING (true);
CREATE POLICY "Public can view product option items" ON public.product_option_items FOR SELECT USING (true);

-- Management policies for options
CREATE POLICY "Users can manage their product options" ON public.product_options
  FOR ALL
  USING (product_id IN (SELECT id FROM public.products WHERE store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid())));

CREATE POLICY "Users can manage their product option items" ON public.product_option_items
  FOR ALL
  USING (option_id IN (SELECT id FROM public.product_options WHERE product_id IN (SELECT product_id FROM public.product_options WHERE id = option_id)));
