
-- Fix RLS Policy for store_staff insert
-- The previous policy might have been created without 'WITH CHECK' for INSERT operations.
-- This script drops the old policy and creates a comprehensive one allowing INSERT/UPDATE/DELETE/SELECT.

DROP POLICY IF EXISTS "Owners can manage staff" ON public.store_staff;

CREATE POLICY "Owners can manage staff" ON public.store_staff
FOR ALL
USING (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()))
WITH CHECK (store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid()));
