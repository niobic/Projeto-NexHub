-- Atualização da tabela de lojas (Stores)
ALTER TABLE stores ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS logo_url TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS primary_color TEXT DEFAULT '#561C24';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS email TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS address TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS opening_hours JSONB DEFAULT '{"monday": {"open": "08:00", "close": "18:00", "closed": false}}';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS delivery_settings JSONB DEFAULT '{"type": "fixed", "fee": 0, "free_shipping_min": 0, "pickup_enabled": true}';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS payment_settings JSONB DEFAULT '{"type": "whatsapp", "pix_key": "", "pix_key_type": "cpf"}';

-- Atualização da tabela de pedidos (Orders)
ALTER TABLE orders ADD COLUMN IF NOT EXISTS customer_phone TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_method TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS address JSONB;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS items JSONB; -- Para salvar os itens do carrinho como JSON

-- Tabela para Opções de Produtos (Ex: Tamanho, Adicionais)
CREATE TABLE IF NOT EXISTS product_options (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT CHECK (type IN ('single', 'multiple')) NOT NULL,
  required BOOLEAN DEFAULT false,
  min_selection INTEGER DEFAULT 0,
  max_selection INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Tabela para Itens das Opções (Ex: P, M, G, Bacon, Queijo)
CREATE TABLE IF NOT EXISTS product_option_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  option_id UUID REFERENCES product_options(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  price DECIMAL(10, 2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Políticas de Segurança (Row Level Security)
ALTER TABLE product_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_option_items ENABLE ROW LEVEL SECURITY;

-- Permitir leitura pública para o cardápio
CREATE POLICY "Public read access for product_options" ON product_options FOR SELECT USING (true);
CREATE POLICY "Public read access for product_option_items" ON product_option_items FOR SELECT USING (true);

-- Permitir edição apenas para donos da loja (simplificado para autenticado por enquanto)
CREATE POLICY "Authenticated users can manage product_options" ON product_options USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can manage product_option_items" ON product_option_items USING (auth.role() = 'authenticated');
