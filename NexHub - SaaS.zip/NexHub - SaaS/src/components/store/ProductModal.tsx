import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { useState, useEffect } from "react";
import { Minus, Plus } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { useIsMobile } from "@/hooks/use-mobile";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
}

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (item: any) => void;
  primaryColor: string;
}

interface OptionItem {
  id: string;
  name: string;
  price: number;
}

interface OptionGroup {
  id: string;
  name: string;
  type: string;
  required: boolean;
  min_selection: number;
  max_selection: number;
  items: OptionItem[];
}

export const ProductModal = ({ product, isOpen, onClose, onAddToCart, primaryColor }: ProductModalProps) => {
  const isMobile = useIsMobile();
  const [quantity, setQuantity] = useState(1);
  const [observations, setObservations] = useState("");
  
  // Stores selected IDs. 
  // For radio: { groupId: itemId }
  // For checkbox: { groupId: [itemId1, itemId2] }
  const [selectedOptions, setSelectedOptions] = useState<Record<string, any>>({});
  
  const [optionGroups, setOptionGroups] = useState<OptionGroup[]>([]);
  const [loadingOptions, setLoadingOptions] = useState(false);

  useEffect(() => {
    if (isOpen && product) {
      setQuantity(1);
      setObservations("");
      setSelectedOptions({});
      fetchOptions(product.id);
    }
  }, [isOpen, product]);

  const fetchOptions = async (productId: string) => {
    setLoadingOptions(true);
    try {
        const { data: optionsData, error: optionsError } = await supabase
          .from('product_options')
          .select('*')
          .eq('product_id', productId)
          .order('created_at', { ascending: true });

        if (optionsError) throw optionsError;

        if (!optionsData || optionsData.length === 0) {
            setOptionGroups([]);
            return;
        }

        const optionIds = optionsData.map(o => o.id);
        const { data: itemsData, error: itemsError } = await supabase
            .from('product_option_items')
            .select('*')
            .in('option_id', optionIds);
            
        if (itemsError) throw itemsError;
        
        // Merge
        const merged: OptionGroup[] = optionsData.map((opt: any) => ({
            id: opt.id,
            name: opt.name,
            type: opt.type,
            required: opt.required,
            min_selection: opt.min_selection,
            max_selection: opt.max_selection,
            items: itemsData?.filter((i: any) => i.option_id === opt.id) || []
        }));

        setOptionGroups(merged);
    } catch (error) {
        console.error(error);
        setOptionGroups([]);
    } finally {
        setLoadingOptions(false);
    }
  };

  const calculateTotal = () => {
     if (!product) return 0;
     let total = product.price;

     optionGroups.forEach(group => {
         const selection = selectedOptions[group.id];
         if (!selection) return;

         if (group.type === 'single') {
             // selection is an itemId string
             const item = group.items.find(i => i.id === selection);
             if (item) total += item.price;
         } else {
             // selection is array of strings
             if (Array.isArray(selection)) {
                 selection.forEach(itemId => {
                     const item = group.items.find(i => i.id === itemId);
                     if (item) total += item.price;
                 });
             }
         }
     });

     return total * quantity;
  };

  const getSelectedOptionsSummary = () => {
      // Return a structured object for the cart
      const summary: any[] = [];
      optionGroups.forEach(group => {
          const selection = selectedOptions[group.id];
          if (!selection) return;

          if (group.type === 'single') {
              const item = group.items.find(i => i.id === selection);
              if (item) summary.push({ group: group.name, item: item.name, price: item.price });
          } else if (Array.isArray(selection)) {
              selection.forEach(itemId => {
                  const item = group.items.find(i => i.id === itemId);
                  if (item) summary.push({ group: group.name, item: item.name, price: item.price });
              })
          }
      });
      return summary;
  }

  const isValid = () => {
      // Check required fields
      for (const group of optionGroups) {
          const selection = selectedOptions[group.id];
          
          if (group.required) {
              if (group.type === 'single') {
                  if (!selection) return false;
              } else {
                  if (!selection || selection.length === 0) return false;
                  if (group.min_selection > 0 && selection.length < group.min_selection) return false;
              }
          }
          
          // Check max selection for multiple
          if (group.type === 'multiple' && group.max_selection && selection?.length > group.max_selection) {
              return false;
          }
      }
      return true;
  };

  const handleAddToCart = () => {
     if (!isValid()) {
         toast.error("Por favor, selecione todas as opções obrigatórias.");
         return;
     }

     onAddToCart({
         product,
         quantity,
         observations,
         optionsSummary: getSelectedOptionsSummary(),
         totalPrice: calculateTotal()
     });
     onClose();
  };

  const Content = product ? (
    <div className="h-full flex flex-col">
       <div className="relative h-64 md:h-80 shrink-0">
          {product.image_url ? (
             <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
          ) : (
             <div className="w-full h-full bg-muted flex items-center justify-center">Sem imagem</div>
          )}
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute top-4 right-4 bg-white/80 hover:bg-white rounded-full z-10"
            onClick={onClose}
          >
             <Minus className="rotate-45" />
          </Button>
       </div>

       <div className="flex-1 overflow-auto p-6 md:p-8">
          <h2 className="text-2xl font-bold mb-2">{product.name}</h2>
          <p className="text-gray-500 mb-6">{product.description}</p>
          <div className="text-lg font-bold text-primary mb-6" style={{color: primaryColor}}>
             {formatCurrency(product.price)}
          </div>

          <div className="space-y-8">
             {loadingOptions && <div className="text-center py-4">Carregando opções...</div>}
             
             {optionGroups.map((group) => {
                 const currentSelection = selectedOptions[group.id];
                 const isSatisfied = group.required 
                    ? (group.type === 'single' ? !!currentSelection : (currentSelection?.length || 0) >= group.min_selection)
                    : true;

                 return (
                    <div key={group.id} className="space-y-4">
                       <div className="flex items-center justify-between bg-gray-50 p-3 -mx-3 md:rounded-lg">
                          <div>
                             <h3 className="font-bold text-gray-900">{group.name}</h3>
                             <p className="text-xs text-gray-500">
                                 {group.type === 'single' ? 'Escolha 1 item' : `Escolha ${group.min_selection > 0 ? `pelo menos ${group.min_selection}` : 'a vontade'}`}
                                 {group.max_selection ? ` (Max ${group.max_selection})` : ''}
                             </p>
                          </div>
                          {group.required ? (
                             <span className={`text-[10px] font-bold text-white px-2 py-1 rounded uppercase ${isSatisfied ? 'bg-green-500' : 'bg-red-500'}`}>
                                {isSatisfied ? 'OK' : 'Obrigatório'}
                             </span>
                          ) : (
                              <span className="text-[10px] bg-gray-200 text-gray-600 px-2 py-1 rounded uppercase">Opcional</span>
                          )}
                       </div>

                       {group.type === 'single' ? (
                           <RadioGroup 
                              onValueChange={(val) => setSelectedOptions(prev => ({...prev, [group.id]: val}))}
                              value={selectedOptions[group.id] || ""}
                           >
                              {group.items.map(opt => (
                                  <div key={opt.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0 hover:bg-gray-50 cursor-pointer" onClick={() => setSelectedOptions(prev => ({...prev, [group.id]: opt.id}))}>
                                     <div className="flex items-center space-x-2">
                                         <RadioGroupItem value={opt.id} id={`${group.id}-${opt.id}`} />
                                         <Label htmlFor={`${group.id}-${opt.id}`} className="font-normal cursor-pointer flex-1">{opt.name}</Label>
                                     </div>
                                     {opt.price > 0 && <span className="text-green-600 font-medium">+ {formatCurrency(opt.price)}</span>}
                                  </div>
                              ))}
                           </RadioGroup>
                       ) : (
                           <div className="space-y-3">
                               {group.items.map(opt => {
                                   const isChecked = (selectedOptions[group.id] || []).includes(opt.id);
                                   return (
                                       <div key={opt.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0 hover:bg-gray-50 cursor-pointer"
                                            onClick={() => {
                                                const current = selectedOptions[group.id] || [];
                                                if (isChecked) {
                                                    setSelectedOptions({...selectedOptions, [group.id]: current.filter((x: string) => x !== opt.id)});
                                                } else {
                                                    if (group.max_selection && current.length >= group.max_selection) {
                                                        toast.error(`Máximo de ${group.max_selection} opções permitidas.`);
                                                        return;
                                                    }
                                                    setSelectedOptions({...selectedOptions, [group.id]: [...current, opt.id]});
                                                }
                                            }}
                                       >
                                           <div className="flex items-center space-x-2">
                                               <Checkbox 
                                                  id={`${group.id}-${opt.id}`} 
                                                  checked={isChecked}
                                                  onCheckedChange={() => {}} // Handled by parent div for larger click area
                                               />
                                               <Label htmlFor={`${group.id}-${opt.id}`} className="font-normal cursor-pointer">{opt.name}</Label>
                                           </div>
                                           {opt.price > 0 && <span className="text-green-600 font-medium">+ {formatCurrency(opt.price)}</span>}
                                       </div>
                                   );
                               })}
                           </div>
                       )}
                    </div>
                 );
             })}

             <div className="space-y-3 pt-4 border-t pb-20">
                <Label className="text-base font-semibold text-gray-800">Observações do Item</Label>
                <Textarea 
                   placeholder="Ex: Tirar cebola, caprichar no molho..." 
                   className="resize-none bg-white border-gray-200 focus:ring-primary h-24"
                   value={observations}
                   onChange={(e) => setObservations(e.target.value)}
                />
             </div>
          </div>
       </div>

       <div className="p-4 border-t bg-white md:p-6 sticky bottom-0 z-20 w-full shadow-[0_-5px_10px_rgba(0,0,0,0.05)]">
           <div className="flex items-center justify-between mb-4">
               <div className="flex items-center border rounded-lg p-1 bg-white">
                   <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setQuantity(Math.max(1, quantity - 1))} disabled={quantity <= 1}>
                       <Minus className="w-4 h-4" />
                   </Button>
                   <span className="w-10 text-center font-bold">{quantity}</span>
                   <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setQuantity(quantity + 1)}>
                       <Plus className="w-4 h-4" />
                   </Button>
               </div>
               <div className="font-bold text-lg text-primary">
                   {formatCurrency(calculateTotal())}
               </div>
           </div>
           <Button 
             className="w-full text-white font-bold h-12 text-lg hover:brightness-95 transition-all shadow-md"
             style={{backgroundColor: primaryColor}}
             onClick={handleAddToCart}
             disabled={!isValid()}
           >
              Adicionar ao pedido
           </Button>
       </div>
    </div>
  ) : null;

  if (isMobile) {
      return (
          <Drawer open={isOpen} onOpenChange={onClose}>
              <DrawerContent className="h-[90vh] p-0 flex flex-col">
                  {Content}
              </DrawerContent>
          </Drawer>
      )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0 h-[85vh] md:h-[90vh] overflow-hidden flex flex-col gap-0 border-none">
        {Content}
      </DialogContent>
    </Dialog>
  );
};

