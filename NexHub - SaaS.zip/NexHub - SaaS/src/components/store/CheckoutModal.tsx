import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useEffect } from "react";
import { formatCurrency } from "@/lib/utils";
import { Minus, Plus, Trash2, Send, MapPin, Store } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useIsMobile } from "@/hooks/use-mobile";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface CartItem {
    id: string; // único para o item do carrinho
    product: any;
    quantity: number;
    observations: string;
    optionsSummary?: any[];
    totalPrice: number;
}

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  store: any;
}

export const CheckoutModal = ({ 
    isOpen, 
    onClose, 
    cart, 
    onUpdateQuantity, 
    onRemoveItem, 
    onClearCart,
    store,
}: CheckoutModalProps) => {
  const isMobile = useIsMobile();
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  
  // Delivery States
  const [deliveryMethod, setDeliveryMethod] = useState<'delivery' | 'pickup'>('delivery');
  const [address, setAddress] = useState({
      street: '',
      number: '',
      neighborhood: '',
      complement: ''
  });
  const [paymentMethod, setPaymentMethod] = useState('pix'); 

  // Derived Values
  const subtotal = cart.reduce((acc, item) => acc + item.totalPrice, 0);
  
  const deliverySettings = store?.delivery_settings || { fee: 0, free_shipping_min: 0, pickup_enabled: true };
  
  const deliveryFee = deliveryMethod === 'pickup' 
      ? 0 
      : (subtotal >= (deliverySettings.free_shipping_min || Infinity) ? 0 : (deliverySettings.fee || 0));

  const total = subtotal + deliveryFee;

  useEffect(() => {
      // Default to pickup if delivery fee is crazy high or not set, or just default logic
      if (!store) return;
      if (deliverySettings.pickup_enabled && !deliverySettings.fee) {
          setDeliveryMethod('pickup');
      }
  }, [store]);

  const handleSendOrder = () => {
      if (!customerName || !customerPhone) {
          toast.error("Por favor, preencha seu nome e telefone.");
          return;
      }
      if (deliveryMethod === 'delivery' && (!address.street || !address.number || !address.neighborhood)) {
          toast.error("Por favor, preencha o endereço completo.");
          return;
      }

      const saveOrder = async () => {
        try {
            const { error } = await supabase.from('orders').insert({
                store_id: store.id,
                customer_name: customerName,
                customer_phone: customerPhone,
                total: total,
                status: 'pending',
                payment_method: paymentMethod,
                delivery_method: deliveryMethod,
                address: deliveryMethod === 'delivery' ? address : null,
                items: cart, // Supabase JSONB column
                notes: '' 
            });

            if (error) throw error;
            
            toast.success("Pedido registrado com sucesso!");
        } catch (err) {
            console.error("Erro ao salvar pedido", err);
            toast.error("Erro ao registrar pedido no sistema");
        }
      };

      saveOrder();


      // 2. Build WhatsApp Message
      // Construir mensagem do WhatsApp
      let message = `*Novo Pedido no ${store.name}*\n`;
      message += `--------------------------------\n`;
      message += `*Cliente:* ${customerName}\n`;
      message += `*Tel:* ${customerPhone}\n\n`;
      
      message += `*Tipo de Entrega:* ${deliveryMethod === 'delivery' ? '🛵 Entrega' : '🏪 Retirada'}\n`;
      if (deliveryMethod === 'delivery') {
          message += `*Endereço:* ${address.street}, ${address.number} - ${address.neighborhood}\n`;
          if (address.complement) message += `_Compl: ${address.complement}_\n`;
      }
      message += `*Pagamento:* ${paymentMethod === 'pix' ? 'Pix' : 'Dinheiro/Cartão'}\n\n`;

      message += `*Resumo do Pedido:*\n`;
      cart.forEach((item) => {
          message += `${item.quantity}x ${item.product.name} - ${formatCurrency(item.totalPrice)}\n`;
          
          if (item.optionsSummary && item.optionsSummary.length > 0) {
              item.optionsSummary.forEach((opt: any) => {
                  message += `   + ${opt.name} (${opt.group})\n`;
              });
          }

          if (item.observations) {
             message += `   _Obs: ${item.observations}_\n`;
          }
          message += `\n`;
      });

      message += `--------------------------------\n`;
      message += `Subtotal: ${formatCurrency(subtotal)}\n`;
      if (deliveryMethod === 'delivery') {
          message += `Taxa de Entrega: ${deliveryFee === 0 ? 'Grátis' : formatCurrency(deliveryFee)}\n`;
      }
      message += `*Total Final: ${formatCurrency(total)}*`;

      const encodedMessage = encodeURIComponent(message);
      const phone = store.phone ? store.phone.replace(/\D/g, '') : '';
      
      if (phone) {
          window.open(`https://wa.me/55${phone}?text=${encodedMessage}`, '_blank');
      } else {
          toast.error("Erro: Telefone da loja não configurado.");
      }
      
      onClearCart();
      onClose();
  };

  const Content = (
    <div className="flex flex-col h-full max-h-[90vh]">
       <DialogHeader className="px-6 py-4 border-b shrink-0">
          <DialogTitle>Finalizar Pedido</DialogTitle>
       </DialogHeader>

       <div className="flex-1 overflow-y-auto">
          <div className="px-6 py-6 space-y-8">
             {/* 1. Itens */}
             <section className="space-y-4">
                 <h3 className="font-semibold text-lg flex items-center"><Store className="w-4 h-4 mr-2" /> Resumo</h3>
                 {cart.length === 0 ? <p className="text-muted-foreground">Sacola vazia.</p> : (
                     <div className="space-y-4">
                        {cart.map((item) => (
                             <div key={item.id} className="flex justify-between items-start text-sm">
                                 <div>
                                     <div className="font-medium">
                                         {item.quantity}x {item.product.name}
                                     </div>
                                     <div className="text-muted-foreground text-xs">
                                         {item.optionsSummary?.map((o:any) => `${o.item}, `)}
                                     </div>
                                     {item.observations && <div className="text-xs italic text-muted-foreground">"{item.observations}"</div>}
                                 </div>
                                 <div className="text-right">
                                     <div>{formatCurrency(item.totalPrice)}</div>
                                     <Button 
                                        variant="ghost" 
                                        size="sm" 
                                        className="h-6 w-6 p-0 text-destructive mt-1" 
                                        onClick={() => onRemoveItem(item.id)}
                                     >
                                         <Trash2 className="w-3 h-3" />
                                     </Button>
                                 </div>
                             </div>
                        ))}
                     </div>
                 )}
             </section>

             {/* 2. Dados Cliente */}
             <section className="space-y-4 border-t pt-4">
                 <h3 className="font-semibold text-lg">Seus Dados</h3>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <div className="space-y-2">
                         <Label>Nome *</Label>
                         <Input value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Seu nome" />
                     </div>
                     <div className="space-y-2">
                         <Label>WhatsApp/Celular *</Label>
                         <Input value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} placeholder="(00) 00000-0000" />
                     </div>
                 </div>
             </section>

             {/* 3. Entrega */}
             <section className="space-y-4 border-t pt-4">
                 <h3 className="font-semibold text-lg flex items-center"><MapPin className="w-4 h-4 mr-2" /> Entrega</h3>
                 
                 <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg text-sm text-primary mb-2">
                    Preencha seu endereço abaixo para calcular a entrega
                 </div>

                 <RadioGroup 
                    value={deliveryMethod} 
                    onValueChange={(v: 'delivery' | 'pickup') => setDeliveryMethod(v)} 
                    className="grid grid-cols-2 gap-4"
                 >
                    <div className={`border rounded-lg p-4 cursor-pointer hover:bg-gray-50 flex items-center justify-between ${deliveryMethod === 'delivery' ? 'border-primary bg-primary/5' : ''}`}>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="delivery" id="delivery" />
                            <Label htmlFor="delivery" className="cursor-pointer">Entrega</Label>
                        </div>
                        <span className="text-sm font-medium">
                            {store.delivery_settings?.fee === 0 || subtotal >= store.delivery_settings?.free_shipping_min ? 'Grátis' : formatCurrency(store.delivery_settings?.fee || 0)}
                        </span>
                    </div>

                    {deliverySettings.pickup_enabled && (
                        <div className={`border rounded-lg p-4 cursor-pointer hover:bg-gray-50 flex items-center justify-between ${deliveryMethod === 'pickup' ? 'border-primary bg-primary/5' : ''}`}>
                            <div className="flex items-center space-x-2">
                                <RadioGroupItem value="pickup" id="pickup" />
                                <Label htmlFor="pickup" className="cursor-pointer">Retirada</Label>
                            </div>
                            <span className="text-sm font-medium text-green-600">Grátis</span>
                        </div>
                    )}
                 </RadioGroup>

                 {deliveryMethod === 'delivery' && (
                     <div className="space-y-3 bg-gray-50 p-4 rounded-lg animate-in fade-in slide-in-from-top-2">
                         <div className="grid grid-cols-3 gap-3">
                             <div className="col-span-2 space-y-1">
                                 <Label>Rua</Label>
                                 <Input value={address.street} onChange={e => setAddress({...address, street: e.target.value})} placeholder="Av. Principal" />
                             </div>
                             <div className="space-y-1">
                                 <Label>Número</Label>
                                 <Input value={address.number} onChange={e => setAddress({...address, number: e.target.value})} placeholder="123" />
                             </div>
                         </div>
                         <div className="grid grid-cols-2 gap-3">
                             <div className="space-y-1">
                                 <Label>Bairro</Label>
                                 <Input value={address.neighborhood} onChange={e => setAddress({...address, neighborhood: e.target.value})} placeholder="Centro" />
                             </div>
                             <div className="space-y-1">
                                 <Label>Complemento</Label>
                                 <Input value={address.complement} onChange={e => setAddress({...address, complement: e.target.value})} placeholder="Apto 101" />
                             </div>
                         </div>
                     </div>
                 )}
             </section>

             {/* 4. Pagamento */}
             <section className="space-y-4 border-t pt-4 pb-4">
                 <h3 className="font-semibold text-lg">Pagamento</h3>
                 <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-2">
                     <div className="flex items-center space-x-2">
                         <RadioGroupItem value="pix" id="pix" />
                         <Label htmlFor="pix">Pix (Chave na próxima etapa)</Label>
                     </div>
                     <div className="flex items-center space-x-2">
                         <RadioGroupItem value="card" id="card" />
                         <Label htmlFor="card">Cartão na entrega/retirada</Label>
                     </div>
                     <div className="flex items-center space-x-2">
                         <RadioGroupItem value="money" id="money" />
                         <Label htmlFor="money">Dinheiro</Label>
                     </div>
                 </RadioGroup>
             </section>
          </div>
       </div>

       <div className="p-6 border-t bg-gray-50 shrink-0">
           <div className="space-y-2 mb-4">
               <div className="flex justify-between text-sm">
                   <span>Subtotal</span>
                   <span>{formatCurrency(subtotal)}</span>
               </div>
               <div className="flex justify-between text-sm">
                   <span>Taxa de Entrega</span>
                   <span className={deliveryFee === 0 ? "text-green-600" : ""}>
                       {deliveryFee === 0 ? "Grátis" : formatCurrency(deliveryFee)}
                   </span>
               </div>
               <div className="flex justify-between font-bold text-lg pt-2 border-t">
                   <span>Total</span>
                   <span>{formatCurrency(total)}</span>
               </div>
           </div>
           
           <Button 
             className="w-full h-12 text-lg font-bold" 
             style={{backgroundColor: store.primary_color}}
             onClick={handleSendOrder}
             disabled={cart.length === 0}
           >
               <Send className="w-5 h-5 mr-2" />
               Enviar Pedido no WhatsApp
           </Button>
       </div>
    </div>
  );

  if (isMobile) {
      return (
          <Drawer open={isOpen} onOpenChange={onClose}>
              <DrawerContent className="h-[95vh] p-0 flex flex-col">
                  {Content}
              </DrawerContent>
          </Drawer>
      )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg p-0 h-[90vh] md:h-auto overflow-hidden flex flex-col gap-0 border-none">
        {Content}
      </DialogContent>
    </Dialog>
  );
};
