
import { useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

interface Category {
  id: string;
  name: string;
}

interface CategoryNavProps {
  categories: Category[];
  activeCategory: string | null;
  onSelect: (categoryId: string) => void;
  primaryColor: string;
}

export const CategoryNav = ({ categories, activeCategory, onSelect, primaryColor }: CategoryNavProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to active category pill
  useEffect(() => {
    if (activeCategory && scrollRef.current) {
      const activeEl = document.getElementById(`cat-pill-${activeCategory}`);
      if (activeEl) {
        const container = scrollRef.current;
        const scrollLeft = activeEl.offsetLeft - container.offsetWidth / 2 + activeEl.offsetWidth / 2;
        container.scrollTo({ left: scrollLeft, behavior: "smooth" });
      }
    }
  }, [activeCategory]);

  if (categories.length === 0) return null;

  return (
    <div className="sticky top-[80px] z-30 bg-gray-50/95 backdrop-blur-sm pt-2 pb-4 shadow-sm">
      <div 
        ref={scrollRef}
        className="flex items-center gap-2 overflow-x-auto px-4 pb-2 hide-scrollbar scroll-smooth"
      >
        {categories.map((cat) => (
          <button
            key={cat.id}
            id={`cat-pill-${cat.id}`}
            onClick={() => onSelect(cat.id)}
            className={cn(
              "whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 border",
              activeCategory === cat.id 
                ? "text-white shadow-md transform scale-105" 
                : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
            )}
            style={activeCategory === cat.id ? { backgroundColor: primaryColor, borderColor: primaryColor } : {}}
          >
            {cat.name}
          </button>
        ))}
      </div>
    </div>
  );
};
