import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, ImageIcon, List } from 'lucide-react';
import { useStore } from '@/contexts/StoreContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from '@/lib/utils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ProductOptionsManager } from './ProductOptionsManager';

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  category_id: string | null;
  stock: number | null;
  image_url: string | null;
  status: string;
  store_id?: string;
}

interface Category {
  id: string;
  name: string;
  sort_order: number;
  active: boolean;
  store_id?: string;
}

export const CatalogPage = () => {
  const { selectedStore } = useStore();
  
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (selectedStore?.id) {
      fetchData();
    }
  }, [selectedStore]);

  const fetchData = async () => {
    if (!selectedStore?.id) return;
    setLoading(true);
    try {
      const [prodRes, catRes] = await Promise.all([
        supabase.from('products').select('*').eq('store_id', selectedStore.id),
        supabase.from('categories').select('*').eq('store_id', selectedStore.id).order('sort_order', { ascending: true })
      ]);

      if (prodRes.error) throw prodRes.error;
      if (catRes.error) throw catRes.error;

      setProducts(prodRes.data || []);
      setCategories(catRes.data || []);
    } catch (error) {
      console.error('Error fetching catalog:', error);
      toast.error('Erro ao carregar catálogo');
    } finally {
      setLoading(false);
    }
  };
  
  // Product States
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category_id: 'none',
    stock: '',
    image_url: '',
  });

  // Category States
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    sort_order: '0',
    active: true
  });

  // Options State
  const [optionsManagementProduct, setOptionsManagementProduct] = useState<Product | null>(null);

  // --- Product Handlers ---

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStore?.id) return;

    const productData = {
      store_id: selectedStore.id,
      name: formData.name,
      description: formData.description || null,
      price: parseFloat(formData.price) || 0,
      category_id: formData.category_id === 'none' ? null : formData.category_id,
      stock: parseInt(formData.stock) || 0,
      image_url: formData.image_url || null,
      status: 'active',
    };

    try {
      if (editingProduct) {
        const { error } = await supabase
          .from('products')
          .update(productData)
          .eq('id', editingProduct.id);

        if (error) throw error;
        toast.success('Produto atualizado!');
      } else {
        const { error } = await supabase
          .from('products')
          .insert(productData);

        if (error) throw error;
        toast.success('Produto criado!');
      }

      setIsDialogOpen(false);
      resetProductForm();
      fetchData();
    } catch (error) {
      console.error(error);
      toast.error('Erro ao salvar produto');
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description || '',
      price: product.price.toString(),
      category_id: product.category_id || 'none',
      stock: (product.stock || 0).toString(),
      image_url: product.image_url || '',
    });
    setIsDialogOpen(true);
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este produto?')) return;
    
    try {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) throw error;
      toast.success('Produto excluído!');
      fetchData();
    } catch (error) {
      console.error(error);
      toast.error('Erro ao excluir produto');
    }
  };

  const resetProductForm = () => {
    setEditingProduct(null);
    setFormData({
      name: '',
      description: '',
      price: '',
      category_id: 'none',
      stock: '',
      image_url: '',
    });
  };

  // --- Category Handlers ---

  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStore?.id) return;

    const data = {
      store_id: selectedStore.id,
      name: categoryForm.name,
      sort_order: parseInt(categoryForm.sort_order) || 0,
      active: categoryForm.active
    };

    try {
      if (editingCategory) {
        const { error } = await supabase
          .from('categories')
          .update(data)
          .eq('id', editingCategory.id);
        
        if (error) throw error;
        toast.success("Categoria atualizada");
      } else {
        const { error } = await supabase
          .from('categories')
          .insert(data);
        
        if (error) throw error;
        toast.success("Categoria criada");
      }
      
      setIsCategoryDialogOpen(false);
      resetCategoryForm();
      fetchData();
    } catch (error) {
      console.error(error);
      toast.error('Erro ao salvar categoria');
    }
  };

  const handleEditCategory = (cat: Category) => {
    setEditingCategory(cat);
    setCategoryForm({
       name: cat.name,
       sort_order: cat.sort_order.toString(),
       active: cat.active
    });
    setIsCategoryDialogOpen(true);
  }

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Tem certeza? Produtos nesta categoria ficarão sem categoria.')) return;
    
    try {
      const { error } = await supabase.from('categories').delete().eq('id', id);
      if (error) throw error;
      toast.success('Categoria excluída');
      fetchData();
    } catch (error) {
      console.error(error);
      toast.error('Erro ao excluir categoria');
    }
  };

  const resetCategoryForm = () => {
    setEditingCategory(null);
    setCategoryForm({ name: '', sort_order: '0', active: true });
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="products" className="w-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger value="products" className="data-[state=active]:bg-background data-[state=active]:shadow-sm">Produtos</TabsTrigger>
            <TabsTrigger value="categories" className="data-[state=active]:bg-background data-[state=active]:shadow-sm">Categorias</TabsTrigger>
          </TabsList>

          <div className="flex gap-2">
             <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
                  <DialogTrigger asChild>
                     <Button variant="outline" onClick={resetCategoryForm}>
                         <List className="w-4 h-4 mr-2" /> Nova Categoria
                     </Button>
                  </DialogTrigger>
                  <DialogContent>
                      <DialogHeader>
                          <DialogTitle>{editingCategory ? 'Editar' : 'Nova'} Categoria</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleCategorySubmit} className="space-y-4">
                          <div className="space-y-2">
                              <Label>Nome da Categoria</Label>
                              <Input 
                                 required 
                                 value={categoryForm.name} 
                                 onChange={e => setCategoryForm({...categoryForm, name: e.target.value})} 
                                 placeholder="Ex: Bebidas, Lanches..." 
                              />
                          </div>
                          <div className="space-y-2">
                              <Label>Ordem de Exibição</Label>
                              <Input 
                                 type="number"
                                 value={categoryForm.sort_order} 
                                 onChange={e => setCategoryForm({...categoryForm, sort_order: e.target.value})} 
                                 placeholder="0"
                              />
                              <p className="text-xs text-muted-foreground">Menores números aparecerão primeiro no cardápio.</p>
                          </div>
                          <Button type="submit" className="w-full">Salvar</Button>
                      </form>
                  </DialogContent>
              </Dialog>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={resetProductForm} className="bg-primary hover:bg-primary-light text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Novo Produto
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>{editingProduct ? 'Editar Produto' : 'Novo Produto'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleProductSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome do Produto</Label>
                    <Input
                      id="name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Ex: X-Bacon"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="category">Categoria</Label>
                    <Select 
                      value={formData.category_id} 
                      onValueChange={(val) => setFormData({...formData, category_id: val})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Sem Categoria</SelectItem>
                        {categories.map(cat => (
                           <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Descrição</Label>
                    <textarea
                      className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Ingredientes, detalhes..."
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="price">Preço (R$)</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        min="0"
                        required
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                        placeholder="0,00"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="stock">Estoque (Opcional)</Label>
                      <Input
                        id="stock"
                        type="number"
                        min="0"
                        value={formData.stock}
                        onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="image">URL da Imagem</Label>
                    <Input
                      id="image"
                      type="url"
                      value={formData.image_url}
                      onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                      placeholder="https://..."
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    {editingProduct ? 'Salvar Alterações' : 'Criar Produto'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <TabsContent value="products" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {products.map((product) => {
              const catName = categories.find(c => c.id === product.category_id)?.name || 'Sem Categoria';
              return (
                <Card key={product.id} className="p-4 flex flex-col justify-between hover:shadow-lg transition-shadow">
                  <div className="space-y-4">
                    <div className="aspect-video w-full bg-muted rounded-md flex items-center justify-center overflow-hidden">
                      {product.image_url ? (
                        <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
                      ) : (
                        <ImageIcon className="w-10 h-10 text-muted-foreground opacity-50" />
                      )}
                    </div>
                    <div>
                      <div className="flex justify-between items-start">
                         <h3 className="font-semibold text-lg">{product.name}</h3>
                         <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">{catName}</span>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                        {product.description || 'Sem descrição'}
                      </p>
                      <p className="font-bold text-primary mt-2">
                        {formatCurrency(product.price)}
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 mt-4 pt-4 border-t">
                    <Button variant="outline" size="sm" onClick={() => setOptionsManagementProduct(product)}>
                      <List className="w-4 h-4 mr-2" />
                      Opções
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleEditProduct(product)}>
                      <Edit className="w-4 h-4 mr-2" />
                      Editar
                    </Button>
                    <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDeleteProduct(product.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
           <Card className="overflow-hidden">
               {categories.length === 0 ? (
                  <div className="p-12 text-center text-muted-foreground flex flex-col items-center">
                    <List className="w-12 h-12 mb-3 opacity-20 relative" />
                    <p>Nenhuma categoria criada.</p>
                  </div>
               ) : (
                 <div className="divide-y">
                     {categories.map(cat => (
                         <div key={cat.id} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                             <div className="flex items-center gap-4">
                                 <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-xs ring-1 ring-primary/20">
                                     {cat.sort_order}
                                 </div>
                                 <span className="font-medium">{cat.name}</span>
                             </div>
                             <div className="flex gap-1">
                                 <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => handleEditCategory(cat)}>
                                     <Edit className="w-4 h-4" />
                                 </Button>
                                 <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDeleteCategory(cat.id)}>
                                     <Trash2 className="w-4 h-4" />
                                 </Button>
                             </div>
                         </div>
                     ))}
                 </div>
               )}
           </Card>
        </TabsContent>
      </Tabs>

      {optionsManagementProduct && (
        <ProductOptionsManager 
            open={!!optionsManagementProduct} 
            onOpenChange={(open) => !open && setOptionsManagementProduct(null)}
            productId={optionsManagementProduct.id}
            productName={optionsManagementProduct.name}
        />
      )}
    </div>
  );
};
