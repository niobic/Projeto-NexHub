import { ReactNode, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useStore } from '@/contexts/StoreContext';
import { Button } from '@/components/ui/button';
import { 
  Store, ClipboardList, Box, Users, Wallet, Settings, 
  LogOut, Plus, Bell, ChevronDown, Menu, X, UtensilsCrossed, Receipt, UserCog
} from 'lucide-react';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface DashboardLayoutProps {
  children: ReactNode;
  currentPage: string;
  pageTitle: string;
  onPageChange: (page: string) => void;
  onNewAction?: () => void;
  newActionLabel?: string;
  onCreateStore?: () => void;
}

const menuItems = [
  { id: 'overview', icon: Store, label: 'Visão Geral' },
  { id: 'orders', icon: ClipboardList, label: 'Pedidos' },
  { id: 'catalog', icon: Box, label: 'Cardápio / Produtos' },
  { id: 'customers', icon: Users, label: 'Clientes' },
  { id: 'finance', icon: Wallet, label: 'Financeiro' },
  { id: 'settings', icon: Settings, label: 'Configurações da Loja' },
];

export const DashboardLayout = ({  
  children, 
  currentPage, 
  pageTitle, 
  onPageChange,
  onNewAction,
  newActionLabel,
  onCreateStore
}: DashboardLayoutProps) => {
  const { user, signOut } = useAuth();
  const { stores, selectedStore, setSelectedStore } = useStore();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    toast.success('Logout realizado com sucesso!');
    navigate('/');
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-sidebar text-sidebar-foreground flex flex-col transform transition-transform lg:transform-none ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-6 border-b border-sidebar-border flex items-center justify-between">
          <span className="text-2xl font-extrabold">
            Nex<span className="text-sidebar-primary">Hub</span>
          </span>
          <button className="lg:hidden text-sidebar-foreground" onClick={() => setSidebarOpen(false)}>
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Store Selector */}
        {stores.length > 0 && (
          <div className="p-4 border-b border-sidebar-border">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-full flex items-center justify-between p-3 rounded-lg bg-sidebar-accent hover:bg-sidebar-accent/80 transition-colors">
                  <div className="flex items-center gap-2 min-w-0">
                    <Store className="w-4 h-4 flex-shrink-0" />
                    <span className="truncate text-sm font-medium">{selectedStore?.name || 'Selecionar Loja'}</span>
                  </div>
                  <ChevronDown className="w-4 h-4 flex-shrink-0" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                {stores.map((store) => (
                  <DropdownMenuItem 
                    key={store.id}
                    onClick={() => setSelectedStore(store)}
                    className={selectedStore?.id === store.id ? 'bg-accent' : ''}
                  >
                    {store.name}
                  </DropdownMenuItem>
                ))}
                
                {onCreateStore && (
                  <>
                    <div className="h-px bg-border my-1" />
                    <DropdownMenuItem onClick={onCreateStore} className="gap-2 cursor-pointer">
                      <Plus className="w-4 h-4" />
                      Criar Nova Loja
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}

        <nav className="flex-1 py-4 overflow-y-auto">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onPageChange(item.id);
                setSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-6 py-3 text-left transition-colors border-l-4 ${
                currentPage === item.id 
                  ? 'bg-sidebar-accent border-sidebar-primary text-sidebar-foreground' 
                  : 'border-transparent text-sidebar-foreground/70 hover:bg-sidebar-accent/50'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-sidebar-primary text-sidebar-primary-foreground rounded-full flex items-center justify-center font-bold text-sm">
              {user?.email?.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user?.email}</p>
              <p className="text-xs text-sidebar-foreground/50">{selectedStore?.name || 'Sem loja'}</p>
            </div>
            <button onClick={handleSignOut} className="text-sidebar-foreground/70 hover:text-sidebar-foreground">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="bg-card border-b border-border px-4 md:px-8 py-4 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <button 
              className="lg:hidden p-2 rounded-lg hover:bg-muted"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-xl md:text-2xl font-bold text-foreground">{pageTitle}</h1>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <Bell className="w-5 h-5" />
            </Button>
            {onNewAction && newActionLabel && (
              <Button onClick={onNewAction} className="bg-primary hover:bg-primary-light text-white">
                <Plus className="w-4 h-4 mr-0 md:mr-2" />
                <span className="hidden md:inline">{newActionLabel}</span>
              </Button>
            )}
          </div>
        </div>

        <div className="p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
};
