import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
    Search, 
    Plus, 
    Minus, 
    ShoppingCart, 
    ChefHat,
    Loader2
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface Product {
    id: string;
    name: string;
    description: string;
    price: number;
    category_id: string;
    image_url: string;
}

interface CartItem {
    product: Product;
    quantity: number;
    observation?: string;
}

export const WaiterNewOrder = ({ storeId, staffId, onCancel, onSuccess }: any) => {
    const [categories, setCategories] = useState<any[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [selectedCategory, setSelectedCategory] = useState<string>('all');
    const [cart, setCart] = useState<CartItem[]>([]);
    const [isCartOpen, setIsCartOpen] = useState(false);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [tableNumber, setTableNumber] = useState('');
    const [customerName, setCustomerName] = useState('');

    useEffect(() => {
        fetchMenu();
    }, [storeId]);

    const fetchMenu = async () => {
        try {
            setLoading(true);
            const { data: cats } = await supabase
                .from('categories')
                .select('*')
                .eq('store_id', storeId)
                .eq('active', true)
                .order('sort_order');
            
            const { data: prods } = await supabase
                .from('products')
                .select('*')
                .eq('store_id', storeId)
                .eq('status', 'active');
            
            if (cats) setCategories(cats);
            if (prods) setProducts(prods);
        } catch (error) {
            console.error(error);
            toast.error('Erro ao carregar cardápio');
        } finally {
            setLoading(false);
        }
    };

    const addToCart = (product: Product) => {
        setCart(prev => {
            const existing = prev.find(item => item.product.id === product.id);
            if (existing) {
                return prev.map(item => 
                    item.product.id === product.id 
                        ? { ...item, quantity: item.quantity + 1 }
                        : item
                );
            }
            return [...prev, { product, quantity: 1 }];
        });
        toast.success('Produto adicionado!');
    };

    const removeFromCart = (productId: string) => {
        setCart(prev => prev.filter(item => item.product.id !== productId));
    };

    const updateQuantity = (productId: string, delta: number) => {
        setCart(prev => prev.map(item => {
            if (item.product.id === productId) {
                const newQty = Math.max(1, item.quantity + delta);
                return { ...item, quantity: newQty };
            }
            return item;
        }));
    };

    const total = cart.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);

    const handleSubmitOrder = async () => {
        if (!tableNumber) {
            toast.error('Informe o número da mesa');
            return;
        }
        
        try {
            setSubmitting(true);
            
            // Call RPC to create command (Waiter context)
            const { data, error } = await supabase.rpc('create_waiter_command', {
                p_store_id: storeId,
                p_table_number: tableNumber,
                p_customer_name: customerName,
                p_waiter_name: 'Garçom App', // Ideally passthrough staff name
                p_items: cart.map(item => ({
                    product_id: item.product.id,
                    quantity: item.quantity,
                    unit_price: item.product.price
                }))
            });

            if (error) throw error;

            toast.success('Pedido enviado para cozinha!');
            setCart([]);
            setIsCartOpen(false);
            if (onSuccess) onSuccess();

        } catch (error: any) {
            console.error(error);
            toast.error('Erro ao enviar pedido: ' + error.message);
        } finally {
            setSubmitting(false);
        }
    };

    const filteredProducts = selectedCategory === 'all' 
        ? products 
        : products.filter(p => p.category_id === selectedCategory);

    return (
        <div className="h-full flex flex-col bg-gray-50 pb-20">
            {/* Header with Search and Cart Trigger */}
            <div className="bg-white p-4 shadow-sm sticky top-0 z-10">
                <div className="flex items-center gap-2 mb-4">
                    <Button variant="ghost" size="icon" onClick={onCancel}>
                        <Minus className="w-6 h-6" />
                    </Button>
                    <h2 className="text-lg font-bold">Novo Pedido</h2>
                    <div className="ml-auto">
                        <Button 
                            className="relative" 
                            variant={cart.length > 0 ? 'default' : 'outline'}
                            onClick={() => setIsCartOpen(true)}
                        >
                            <ShoppingCart className="w-5 h-5" />
                            {cart.length > 0 && (
                                <Badge className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center p-0 rounded-full bg-red-500">
                                    {cart.length}
                                </Badge>
                            )}
                        </Button>
                    </div>
                </div>

                <ScrollArea className="w-full whitespace-nowrap pb-2">
                    <div className="flex gap-2">
                        <Button 
                            variant={selectedCategory === 'all' ? 'default' : 'outline'}
                            onClick={() => setSelectedCategory('all')}
                            className="rounded-full"
                        >
                            Todos
                        </Button>
                        {categories.map(cat => (
                            <Button 
                                key={cat.id}
                                variant={selectedCategory === cat.id ? 'default' : 'outline'}
                                onClick={() => setSelectedCategory(cat.id)}
                                className="rounded-full"
                            >
                                {cat.name}
                            </Button>
                        ))}
                    </div>
                </ScrollArea>
            </div>

            {/* Product Grid */}
            <div className="p-4 grid grid-cols-2 gap-3 overflow-y-auto flex-1">
                {loading ? (
                    <div className="col-span-2 flex justify-center py-10">
                        <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    </div>
                ) : (
                    filteredProducts.map(product => (
                        <Card key={product.id} className="overflow-hidden flex flex-col" onClick={() => addToCart(product)}>
                            <div className="aspect-square bg-gray-100 relative">
                                {product.image_url ? (
                                    <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
                                ) : (
                                    <div className="w-full h-full flex items-center justify-center text-gray-300">
                                        <ChefHat className="w-10 h-10" />
                                    </div>
                                )}
                                <Button size="icon" className="absolute bottom-2 right-2 rounded-full h-8 w-8 shadow-lg">
                                    <Plus className="w-5 h-5" />
                                </Button>
                            </div>
                            <div className="p-3 flex-1 flex flex-col">
                                <h3 className="font-semibold text-sm line-clamp-2 mb-1">{product.name}</h3>
                                <div className="mt-auto font-bold text-primary">
                                    {formatCurrency(product.price)}
                                </div>
                            </div>
                        </Card>
                    ))
                )}
            </div>

            {/* Cart Dialog/Drawer */}
            <Dialog open={isCartOpen} onOpenChange={setIsCartOpen}>
                <DialogContent className="max-h-[80vh] flex flex-col">
                    <DialogHeader>
                        <DialogTitle>Resumo do Pedido</DialogTitle>
                        <DialogDescription>Confirme os itens antes de enviar</DialogDescription>
                    </DialogHeader>

                    <div className="py-4 space-y-4 flex-1 overflow-y-auto">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <label className="text-sm font-medium">Mesa</label>
                                <Input 
                                    placeholder="Nº" 
                                    className="text-center font-bold text-lg"
                                    value={tableNumber}
                                    onChange={e => setTableNumber(e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-sm font-medium">Cliente (Opcional)</label>
                                <Input 
                                    placeholder="Nome" 
                                    value={customerName}
                                    onChange={e => setCustomerName(e.target.value)}
                                />
                            </div>
                        </div>

                        <div className="border-t pt-4 space-y-3">
                            {cart.length === 0 ? (
                                <p className="text-center text-gray-400 py-4">Carrinho vazio</p>
                            ) : (
                                cart.map(item => (
                                    <div key={item.product.id} className="flex justify-between items-center">
                                        <div className="flex-1">
                                            <p className="font-medium text-sm">{item.product.name}</p>
                                            <p className="text-xs text-gray-500">{formatCurrency(item.product.price)}</p>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQuantity(item.product.id, -1)}>
                                                <Minus className="w-3 h-3" />
                                            </Button>
                                            <span className="w-4 text-center text-sm">{item.quantity}</span>
                                            <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQuantity(item.product.id, 1)}>
                                                <Plus className="w-3 h-3" />
                                            </Button>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    <DialogFooter className="border-t pt-4">
                        <div className="w-full flex justify-between items-center mb-4">
                            <span className="font-bold">Total</span>
                            <span className="text-xl font-bold text-primary">{formatCurrency(total)}</span>
                        </div>
                        <Button className="w-full" size="lg" onClick={handleSubmitOrder} disabled={submitting || cart.length === 0}>
                            {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Enviar Pedido para Cozinha'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};
