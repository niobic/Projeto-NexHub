import { motion } from 'framer-motion';
import { Laptop, Layers, Bot, LineChart } from 'lucide-react';

const services = [
  {
    icon: Laptop,
    title: 'Criação de Sites',
    description: 'Sites modernos e responsivos com foco em conversão.',
  },
  {
    icon: Layers,
    title: 'Sistemas Web',
    description: 'Gestão e escalabilidade com plataformas personalizadas.',
  },
  {
    icon: Bot,
    title: 'Automações',
    description: 'Inteligência artificial e bots para otimizar seus processos.',
  },
  {
    icon: LineChart,
    title: 'Consultoria',
    description: 'Estratégia digital para posicionamento de mercado.',
  },
];

export const Services = () => {
  return (
    <section id="servicos" className="py-32 px-4 relative overflow-hidden bg-background">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
      
      <div className="container mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent/10 text-primary-dark font-bold text-xs tracking-widest uppercase mb-6 border border-accent/20">
             <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
             Nossa Expertise
          </div>
          
          <h2 className="text-4xl md:text-5xl font-black text-foreground tracking-tight leading-tight">
            Excelência em cada <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary-light">pixel e processo</span>
          </h2>
          <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
            Combinamos design sofisticado com engenharia robusta para entregar soluções que impulsionam seu negócio.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative bg-white/50 dark:bg-card/50 backdrop-blur-sm rounded-[2rem] p-8 hover:bg-white dark:hover:bg-card border border-border/50 hover:border-primary/20 transition-all duration-500 hover:shadow-2xl hover:shadow-primary/5 hover:-translate-y-2"
            >
              {/* Hover Gradient Border Effect */}
              <div className="absolute inset-0 rounded-[2rem] bg-gradient-to-br from-primary/10 via-transparent to-accent/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>

              <div className="relative z-10">
                <div className="w-16 h-16 mb-8 rounded-2xl bg-gradient-to-br from-background to-muted shadow-inner flex items-center justify-center group-hover:scale-110 transition-transform duration-500 border border-border">
                   <div className="absolute inset-0 bg-primary/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                   <service.icon className="w-7 h-7 text-primary/80 group-hover:text-primary transition-colors duration-300" />
                </div>
                
                <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors leading-tight">
                  {service.title}
                </h3>
                
                <p className="text-muted-foreground text-sm leading-relaxed group-hover:text-foreground/80 transition-colors">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
