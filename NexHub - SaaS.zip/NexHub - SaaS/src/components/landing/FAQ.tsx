import { motion } from 'framer-motion';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Como funciona o controle de estoque?",
    answer: "Nosso sistema permite gerenciar seu estoque em tempo real. Você pode configurar alertas de estoque baixo, pausar automaticamente itens esgotados no cardápio digital e acompanhar a movimentação de entrada e saída de produtos."
  },
  {
    question: "Consigo acompanhar minhas vendas e lucros?",
    answer: "Sim! O dashboard financeiro oferece relatórios detalhados de faturamento, lucro líquido, ticket médio e métodos de pagamento mais utilizados. Tudo isso com gráficos intuitivos para facilitar a tomada de decisão."
  },
  {
    question: "O sistema emite notas fiscais (NFC-e)?",
    answer: "Com certeza. A emissão de NFC-e é totalmente integrada. Você pode emitir notas fiscais diretamente pelo PDV com poucos cliques, garantindo conformidade fiscal para o seu negócio."
  },
  {
    question: "Posso utilizar em quantos dispositivos?",
    answer: "Você pode acessar o dashboard administrativo e o PDV em computadores, tablets e smartphones. Os garçons também podem utilizar o aplicativo de comanda em seus próprios celulares."
  },
  {
    question: "Como funciona a integração com delivery?",
    answer: "Centralizamos todos os seus pedidos em uma única tela. Sejam pedidos do cardápio digital, balcão ou telefone, tudo chega organizado no seu gestor de pedidos, com impressão automática na cozinha."
  }
];

export const FAQ = () => {
  return (
    <section className="py-24 px-4 bg-background">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-bold uppercase tracking-widest text-sm mb-2 block">
            Dúvidas Comuns
          </span>
          <h2 className="text-3xl md:text-4xl font-black text-foreground">
            Perguntas Frequentes
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Tudo o que você precisa saber sobre nossos serviços.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Accordion type="single" collapsible className="w-full space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-border/50 rounded-xl px-4 data-[state=open]:bg-muted/30 data-[state=open]:border-primary/20 transition-all"
              >
                <AccordionTrigger className="text-left text-lg font-semibold hover:no-underline hover:text-primary transition-colors py-6">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base pb-6 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};
