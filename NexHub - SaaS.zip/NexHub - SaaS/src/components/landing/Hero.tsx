import { motion } from 'framer-motion';
import { Check, User, Mail, Phone, Store } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useState } from 'react';
import { toast } from 'sonner';

const benefits = [
  'Catálogo Digital e QR Code',
  'Gestão de Vendas e Serviços',
  'Controle Financeiro e Operacional',
  'Automação de Processos e Tarefas',
];

export const Hero = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    volume: '',
    hasComputer: '',
    revenue: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Obrigado! Entraremos em contato em breve.');
    setFormData({ name: '', email: '', phone: '', company: '', volume: '', hasComputer: '', revenue: '' });
  };

  return (
    <header className="min-h-screen gradient-hero flex items-center pt-24 pb-12 px-4">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: [0.2, 0.8, 0.2, 1] }}
            className="text-white"
          >
            <h1 className="text-4xl md:text-5xl lg:text-[3.2rem] font-extrabold leading-tight mb-6">
              Economize tempo e dinheiro com uma gestão completa do seu negócio
            </h1>
            
            <div className="w-full h-px bg-white/20 my-6" />
            
            <ul className="space-y-4">
              {benefits.map((benefit, index) => (
                <motion.li
                  key={benefit}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                  className="flex items-center gap-3 text-lg"
                >
                  <Check className="w-6 h-6 text-accent flex-shrink-0" />
                  <span>{benefit}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* Right Form Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-white rounded-xl p-6 md:p-8 shadow-2xl"
          >
            <h3 className="text-xl font-bold text-foreground mb-1">
              Automatize seu atendimento hoje
            </h3>
            <p className="text-muted-foreground text-sm mb-6">
              Não é necessário incluir dados do cartão de crédito
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Seu nome"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
              
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="Seu email pessoal"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
              
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="tel"
                  placeholder="Seu WhatsApp"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
              
              <div className="relative">
                <Store className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Nome da sua Empresa"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">Volume de vendas/atendimentos diários</Label>
                <div className="grid grid-cols-2 gap-3">
                  <label className={`flex items-center justify-center gap-2 p-3 rounded-lg cursor-pointer transition-all border ${formData.volume === 'menos10' ? 'bg-primary text-primary-foreground border-accent' : 'bg-primary/90 text-white border-transparent hover:bg-primary-light'}`}>
                    <input
                      type="radio"
                      name="volume"
                      value="menos10"
                      checked={formData.volume === 'menos10'}
                      onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
                      className="sr-only"
                    />
                    <span className="font-medium text-sm">Menos de 10</span>
                  </label>
                  <label className={`flex items-center justify-center gap-2 p-3 rounded-lg cursor-pointer transition-all border ${formData.volume === 'mais10' ? 'bg-primary text-primary-foreground border-accent' : 'bg-primary/90 text-white border-transparent hover:bg-primary-light'}`}>
                    <input
                      type="radio"
                      name="volume"
                      value="mais10"
                      checked={formData.volume === 'mais10'}
                      onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
                      className="sr-only"
                    />
                    <span className="font-medium text-sm">Mais de 10</span>
                  </label>
                </div>
              </div>

              <Button type="submit" className="w-full bg-primary hover:bg-primary-light text-white font-semibold py-6 text-lg">
                Contratar Agora
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </header>
  );
};
