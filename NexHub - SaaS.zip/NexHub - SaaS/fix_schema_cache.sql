-- FORCE REFRESH OF SCHEMA CACHE
-- Execute este script no SQL Editor do Supabase para corrigir o erro "schema cache"

-- 1. Garantir que as colunas existem (caso a execução anterior tenha falhado silenciosamente)
ALTER TABLE stores ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS logo_url TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS primary_color TEXT DEFAULT '#561C24';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS email TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS address TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS opening_hours JSONB DEFAULT '{"monday": {"open": "08:00", "close": "18:00", "closed": false}}';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS delivery_settings JSONB DEFAULT '{"type": "fixed", "fee": 0, "free_shipping_min": 0, "pickup_enabled": true}';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS payment_settings JSONB DEFAULT '{"type": "whatsapp", "pix_key": "", "pix_key_type": "cpf"}';

-- 2. Notificar o PostgREST para recarregar o cache de schema
NOTIFY pgrst, 'reload schema';
